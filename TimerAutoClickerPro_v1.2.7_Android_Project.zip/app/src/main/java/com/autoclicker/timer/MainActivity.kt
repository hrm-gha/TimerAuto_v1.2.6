package com.autoclicker.timer

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var presetRepo: PresetRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        presetRepo = PresetRepository(this)
        initWebView()
        loadIdealUI()
    }

    override fun onResume() {
        super.onResume()
        // Refresh permission states to WebView
        checkPermissionsAndNotify()
        webView.evaluateJavascript(
            "if (typeof loadPresets === 'function') loadPresets(); if (typeof updateSavedPosLabel === 'function') updateSavedPosLabel();",
            null
        )
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebView() {
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    checkPermissionsAndNotify()
                }
            }
            addJavascriptInterface(WebAppInterface(this@MainActivity), "AndroidBridge")
        }
        setContentView(webView)
    }

    private fun checkPermissionsAndNotify() {
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true

        val hasAccessibility = AutoClickAccessibilityService.isRunning()

        val js = "javascript:if(window.updatePermissions){ window.updatePermissions($hasOverlay, $hasAccessibility); }"
        webView.post { webView.evaluateJavascript(js, null) }
    }

    inner class WebAppInterface(private val context: Context) {

        @JavascriptInterface
        fun requestOverlayPermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(context)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    startActivity(intent)
                }
            }
        }

        @JavascriptInterface
        fun requestAccessibilityPermission() {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                startActivity(intent)
                Toast.makeText(
                    context,
                    "リストから「あたり！予約成功クリッカー」をONにしてください\n※グレーで押せない場合は、端末の設定>アプリ>あたり！予約成功クリッカー>右上の︙から「制限付き設定を許可」をタップしてください",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun openAppSettings() {
            try {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                startActivity(intent)
            } catch (e: Exception) {}
        }

        @JavascriptInterface
        fun getPresetsJson(): String {
            return presetRepo.getAllPresetsJson()
        }

        @JavascriptInterface
        fun getLastSelectedPresetId(): String? {
            return presetRepo.getLastSelectedPresetId()
        }

        @JavascriptInterface
        fun setLastSelectedPresetId(id: String) {
            presetRepo.setLastSelectedPresetId(id)
        }

        @JavascriptInterface
        fun savePreset(
            id: String?,
            name: String,
            hour: Int,
            minute: Int,
            second: Int,
            millisecond: Int,
            targetX: Int = -1,
            targetY: Int = -1,
            guideX: Int = -1,
            guideY: Int = -1
        ): String {
            val saved = presetRepo.saveOrUpdatePreset(id, name, hour, minute, second, millisecond, targetX, targetY, guideX, guideY)
            runOnUiThread {
                Toast.makeText(context, "✓ プリセット「${saved.name}」を保存しました\n①:(${saved.targetX}, ${saved.targetY}) 🎯:(${saved.guideX}, ${saved.guideY})", Toast.LENGTH_SHORT).show()
            }
            return saved.id
        }

        @JavascriptInterface
        fun getLastSavedPositionsJson(): String {
            val coords = presetRepo.getLastCoordinates()
            val gson = com.google.gson.Gson()
            return gson.toJson(coords ?: SavedCoordinates(540, 700, 540, 1150))
        }

        @JavascriptInterface
        fun savePositions(target1X: Int, target1Y: Int, guideX: Int, guideY: Int) {
            presetRepo.saveLastCoordinates(target1X, target1Y, guideX, guideY)
            runOnUiThread {
                Toast.makeText(context, "✓ 位置を保存しました: ①($target1X, $target1Y), 🎯($guideX, $guideY)", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun updateAllPresetsCoordinates(target1X: Int, target1Y: Int, guideX: Int, guideY: Int) {
            presetRepo.updateAllPresetsCoordinates(target1X, target1Y, guideX, guideY)
            runOnUiThread {
                Toast.makeText(context, "💾 全プリセットの位置を保存・更新しました！\n①:($target1X, $target1Y) 🎯:($guideX, $guideY)", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun deletePreset(id: String): Boolean {
            val res = presetRepo.deletePreset(id)
            runOnUiThread {
                Toast.makeText(context, "✓ プリセットを削除しました", Toast.LENGTH_SHORT).show()
            }
            return res
        }

        @JavascriptInterface
        fun startFloatingService(
            hour: Int,
            minute: Int,
            second: Int,
            millisecond: Int,
            presetName: String,
            armImmediately: Boolean,
            target1X: Int = -1,
            target1Y: Int = -1,
            guideX: Int = -1,
            guideY: Int = -1
        ) {
            val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true

            if (!hasOverlay) {
                Toast.makeText(context, "⚠️ 最初に「最前面表示」権限を許可してください", Toast.LENGTH_SHORT).show()
                requestOverlayPermission()
                return
            }

            val hasA11y = AutoClickAccessibilityService.isRunning()
            if (!hasA11y) {
                Toast.makeText(context, "⚠️ ユーザー補助がOFFです！自動タップを行うには設定から「あたり！予約成功クリッカー」をONにしてください", Toast.LENGTH_LONG).show()
            }

            val serviceIntent = Intent(context, FloatingOverlayService::class.java).apply {
                putExtra(FloatingOverlayService.EXTRA_HOUR, hour)
                putExtra(FloatingOverlayService.EXTRA_MINUTE, minute)
                putExtra(FloatingOverlayService.EXTRA_SECOND, second)
                putExtra(FloatingOverlayService.EXTRA_MILLISECOND, millisecond)
                putExtra(FloatingOverlayService.EXTRA_PRESET_NAME, presetName)
                putExtra(FloatingOverlayService.EXTRA_ARMED, armImmediately)
                if (target1X > 0) putExtra(FloatingOverlayService.EXTRA_TARGET1_X, target1X)
                if (target1Y > 0) putExtra(FloatingOverlayService.EXTRA_TARGET1_Y, target1Y)
                if (guideX > 0) putExtra(FloatingOverlayService.EXTRA_GUIDE_X, guideX)
                if (guideY > 0) putExtra(FloatingOverlayService.EXTRA_GUIDE_Y, guideY)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }

            Toast.makeText(context, "✓ 最前面フローティングを開始しました！他アプリを開いて配置してください", Toast.LENGTH_LONG).show()

            // Minimize to home so target floats over other apps!
            moveTaskToBack(true)
        }

        @JavascriptInterface
        fun stopFloatingService() {
            try {
                val serviceIntent = Intent(context, FloatingOverlayService::class.java).apply {
                    action = FloatingOverlayService.ACTION_STOP
                }
                context.startService(serviceIntent)
                FloatingOverlayService.instance?.removeAllViewsAndStop()
                this@MainActivity.runOnUiThread {
                    Toast.makeText(context, "🛑 フローティングバーを完全消去・終了しました", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to stop floating service", e)
            }
        }
    }

    private fun loadIdealUI() {
        val html = """
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>Timer Auto Clicker Pro</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; -webkit-tap-highlight-color: transparent; }
  body { background-color: #F8F6F0; color: #0F172A; min-height: 100vh; display: flex; flex-direction: column; justify-content: space-between; padding: 14px; user-select: none; }
  
  /* Header */
  .header { display: flex; align-items: center; justify-content: space-between; padding-top: 4px; }
  .logo-title { display: flex; align-items: center; gap: 8px; }
  .logo-icon { width: 34px; height: 34px; border-radius: 10px; background-color: #6355DE; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 2px 6px rgba(99,85,222,0.3); }
  .app-name { font-size: 19px; font-weight: 900; color: #0F172A; letter-spacing: -0.5px; }
  .header-badges { display: flex; gap: 6px; }
  .badge-pip { padding: 4px 10px; border-radius: 9999px; background-color: #F3E8FF; color: #6355DE; border: 1px solid #D8B4FE; font-size: 11px; font-weight: 700; cursor: pointer; }
  .badge-preset { padding: 4px 10px; border-radius: 9999px; background-color: #FFFFFF; color: #334155; border: 1px solid #E2E8F0; font-size: 11px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 4px; }
  .badge-preset:active { background-color: #F1F5F9; }

  /* Permission Bar (Shows if needed) */
  .perm-box { display: none; background: #FFFBEB; border: 1px solid #FCD34D; border-radius: 12px; padding: 10px; margin-top: 10px; font-size: 12px; }
  .perm-btn { display: inline-block; background: #6355DE; color: white; padding: 4px 10px; border-radius: 6px; font-weight: bold; margin-top: 6px; text-decoration: none; border: none; font-size: 11px; }

  /* Presets Chip Bar */
  .presets-bar { display: flex; gap: 6px; overflow-x: auto; padding: 8px 0; margin-top: 4px; scrollbar-width: none; }
  .presets-bar::-webkit-scrollbar { display: none; }
  .chip-add { background: #6355DE; color: white; border: none; padding: 6px 14px; border-radius: 9999px; font-size: 11px; font-weight: bold; white-space: nowrap; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 5px rgba(99,85,222,0.25); }
  .chip-add:active { transform: scale(0.96); }
  .chip { background: white; border: 1px solid #E2E8F0; padding: 6px 12px; border-radius: 9999px; font-size: 11px; font-weight: 600; color: #334155; white-space: nowrap; cursor: pointer; display: flex; align-items: center; gap: 6px; }
  .chip.active { background: #EEF2FF; border-color: #6355DE; color: #6355DE; font-weight: bold; box-shadow: 0 1px 4px rgba(99,85,222,0.15); }
  .chip-time { font-size: 10px; opacity: 0.75; font-family: monospace; }

  /* Drum Roll Card (Ideal Design from Screenshot) */
  .drum-card { background: white; border-radius: 24px; padding: 22px 16px; margin: 12px 0; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border: 1px solid rgba(226,232,240,0.8); text-align: center; }
  .drum-top-label { display: flex; justify-content: space-between; font-size: 12px; color: #64748B; font-weight: 600; margin-bottom: 12px; }
  .preset-tag-right { color: #6355DE; font-weight: 700; cursor: pointer; text-decoration: underline; }
  
  .time-picker-grid { display: flex; justify-content: center; align-items: center; gap: 6px; }
  .time-col { display: flex; flex-direction: column; align-items: center; width: 68px; }
  .ghost-val { font-size: 18px; color: #94A3B8; font-weight: 500; height: 26px; cursor: pointer; }
  .active-val-box { border-top: 2px solid #0F172A; border-bottom: 2px solid #0F172A; width: 100%; padding: 6px 0; margin: 4px 0; }
  .active-val { font-size: 32px; font-weight: 900; color: #0F172A; letter-spacing: -1px; width: 100%; text-align: center; border: none; outline: none; background: transparent; }
  .colon { font-size: 26px; font-weight: 900; color: #94A3B8; margin-bottom: 4px; }
  
  .ntp-sync-hint { font-size: 11px; color: #64748B; font-weight: 500; margin-top: 16px; }

  /* Quick Settings Box */
  .quick-card { background: white; border-radius: 20px; padding: 14px 16px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); border: 1px solid #E2E8F0; margin-bottom: 12px; }
  .quick-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
  .quick-title { font-size: 13px; font-weight: 800; color: #0F172A; }
  .quick-btns { display: flex; gap: 6px; }
  .q-btn { background: #EEF2FF; border: none; color: #6355DE; font-size: 11px; font-weight: 700; padding: 5px 10px; border-radius: 9999px; cursor: pointer; }
  
  .target-summary { display: flex; justify-content: space-between; align-items: flex-end; }
  .target-big-time { font-size: 24px; font-weight: 900; color: #0F172A; letter-spacing: 0.5px; }
  .target-big-time span { font-size: 16px; color: #64748B; font-weight: 600; }
  .remain-wrap { text-align: right; }
  .remain-label { font-size: 10px; color: #64748B; font-weight: 600; }
  .remain-time { font-size: 15px; font-weight: 800; color: #6355DE; }

  /* Primary Start Button */
  .start-btn { width: 100%; background: #6355DE; color: white; border: none; border-radius: 18px; padding: 16px; font-size: 17px; font-weight: 800; cursor: pointer; box-shadow: 0 6px 18px rgba(99,85,222,0.35); transition: transform 0.1s; }
  .start-btn:active { transform: scale(0.98); }

  /* Preset Management Modal */
  .modal-backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 9999; backdrop-filter: blur(2px); align-items: center; justify-content: center; padding: 16px; }
  .modal-card { background: white; width: 100%; max-width: 380px; border-radius: 28px; padding: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.2); max-height: 85vh; display: flex; flex-direction: column; }
  .modal-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid #F1F5F9; }
  .modal-title { font-size: 16px; font-weight: 900; color: #0F172A; }
  .modal-close { background: #F1F5F9; border: none; width: 28px; height: 28px; border-radius: 14px; color: #64748B; font-weight: bold; cursor: pointer; }
  
  .preset-form { background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 16px; padding: 12px; margin: 12px 0; }
  .form-title { font-size: 11px; font-weight: 700; color: #475569; margin-bottom: 6px; display: flex; justify-content: space-between; }
  .form-input { width: 100%; border: 1px solid #CBD5E1; border-radius: 10px; padding: 8px 10px; font-size: 13px; font-weight: 600; outline: none; margin-bottom: 8px; background: white; }
  .form-input:focus { border-color: #6355DE; }
  .time-input-row { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; font-size: 12px; font-weight: bold; }
  .time-sub-input { width: 48px; text-align: center; border: 1px solid #CBD5E1; border-radius: 8px; padding: 6px; font-size: 14px; font-weight: 800; background: white; }
  .form-btn-row { display: flex; gap: 6px; }
  .form-save-btn { flex: 1; background: #6355DE; color: white; border: none; padding: 8px; border-radius: 10px; font-weight: bold; font-size: 12px; cursor: pointer; }
  .form-cancel-btn { background: #E2E8F0; color: #475569; border: none; padding: 8px 12px; border-radius: 10px; font-weight: bold; font-size: 12px; cursor: pointer; }

  .preset-list { flex: 1; overflow-y: auto; padding-right: 2px; }
  .preset-item { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; border: 1px solid #F1F5F9; border-radius: 14px; margin-bottom: 6px; background: white; }
  .preset-item.active { border-color: #6355DE; background: #FAF5FF; }
  .preset-info { flex: 1; cursor: pointer; }
  .preset-name { font-size: 13px; font-weight: 800; color: #0F172A; }
  .preset-timing { font-size: 11px; font-weight: 600; color: #6355DE; font-family: monospace; }
  .preset-actions { display: flex; gap: 6px; }
  .action-btn { background: #F1F5F9; border: none; width: 28px; height: 28px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 12px; }
  .action-btn.del:hover { background: #FEE2E2; color: #DC2626; }
</style>
</head>
<body>

  <!-- 1. Top Section -->
  <div>
    <div class="header">
      <div class="logo-title">
        <div class="logo-icon">👆</div>
        <div class="app-name">時間指定 <span style="font-size: 11px; background: #EEF2FF; color: #6355DE; padding: 2px 7px; border-radius: 999px; margin-left: 6px; border: 1px solid #C7D2FE; font-weight: bold;">v1.2.7</span></div>
      </div>
      <div class="header-badges">
        <button class="badge-pip" style="background: #FEE2E2; color: #DC2626; border-color: #FECACA;" onclick="stopFloatingOverlay()" title="画面上のバーを完全消去">🛑 バー消去</button>
        <button class="badge-pip" onclick="startAppWithFloating()">📱 最前面化</button>
        <button class="badge-preset" onclick="openPresetModal(null)" title="プリセットを編集・一覧">
          🏷 <span id="currentPresetName">月曜 ヨガ予約</span>
        </button>
      </div>
    </div>

    <!-- Permission Warning Bar (MIUI/Android) -->
    <div class="perm-box" id="permBox">
      <div id="permMsg">⚠️ 必要な権限が不足しています</div>
      <button class="perm-btn" id="permActionBtn" onclick="handlePermAction()">権限を許可する</button>
    </div>

    <!-- Presets Bar -->
    <div class="presets-bar" id="presetsBar">
      <button class="chip-add" onclick="openPresetModal('new')">＋ 登録</button>
      <!-- Dynamic chips will be inserted here -->
    </div>
  </div>

  <!-- 2. Drum Roll Card (Ideal UI) -->
  <div class="drum-card">
    <div class="drum-top-label">
      <span>タップする時刻</span>
      <span class="preset-tag-right" id="cardPresetTag" onclick="openPresetModal(null)">月曜 ヨガ予約</span>
    </div>

    <div class="time-picker-grid">
      <!-- Hour -->
      <div class="time-col">
        <div class="ghost-val" onclick="adjHour(-1)" id="hGhostUp">20</div>
        <div class="active-val-box">
          <input type="number" class="active-val" id="hourInput" value="21" min="0" max="23" onchange="syncFromInput()">
        </div>
        <div class="ghost-val" onclick="adjHour(1)" id="hGhostDown">22</div>
      </div>

      <div class="colon">:</div>

      <!-- Minute -->
      <div class="time-col">
        <div class="ghost-val" onclick="adjMin(-1)" id="mGhostUp">59</div>
        <div class="active-val-box">
          <input type="number" class="active-val" id="minInput" value="00" min="0" max="59" onchange="syncFromInput()">
        </div>
        <div class="ghost-val" onclick="adjMin(1)" id="mGhostDown">01</div>
      </div>

      <div class="colon">:</div>

      <!-- Second -->
      <div class="time-col">
        <div class="ghost-val" id="sGhostUp">58</div>
        <div class="active-val-box">
          <div class="active-val" id="secVal">59</div>
        </div>
        <div class="ghost-val" id="sGhostDown">00</div>
      </div>

      <div class="colon" style="font-size: 20px; align-self: flex-end; margin-bottom: 12px;">.</div>

      <!-- Millisecond -->
      <div class="time-col">
        <div class="ghost-val">49</div>
        <div class="active-val-box">
          <div class="active-val" style="font-size: 26px;">50</div>
        </div>
        <div class="ghost-val">51</div>
      </div>
    </div>

    <div class="ntp-sync-hint">日本標準時 (NICT原子時計) とミリ秒同期</div>
  </div>

  <!-- 3. Bottom Controls -->
  <div>
    <div class="quick-card">
      <div class="quick-header">
        <div class="quick-title">クイック設定</div>
        <div class="quick-btns">
          <button class="q-btn" onclick="setNowTime()">🕒 現在時刻</button>
          <button class="q-btn" onclick="addMins(1)">+1分</button>
          <button class="q-btn" onclick="addMins(5)">+5分</button>
        </div>
      </div>

      <div class="target-summary">
        <div>
          <div style="font-size: 10px; color: #64748B; font-weight: bold; margin-bottom: 2px;">タップ予定時刻</div>
          <div class="target-big-time" id="summaryTime">21 : 00 : 59 <span>.50</span></div>
        </div>
        <div class="remain-wrap">
          <div class="remain-label">残り時間</div>
          <div class="remain-time" id="countdownLabel">00:00:00</div>
        </div>
      </div>
    </div>

    <!-- Saved Positions Banner -->
    <div style="background: #FFFFFF; border-radius: 12px; padding: 10px 14px; margin-bottom: 10px; border: 1px solid #E2E8F0; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
      <div>
        <div style="font-size: 10.5px; font-weight: bold; color: #64748B;">📍 保存中のターゲット位置</div>
        <div id="mainSavedPosLabel" style="font-size: 12.5px; font-weight: bold; color: #1E293B; margin-top: 2px;">①(540, 700) / 🎯(540, 1150)</div>
      </div>
      <button type="button" onclick="saveCurrentCoordsToAllPresets()" style="background: #ECFDF5; color: #059669; border: 1px solid #A7F3D0; font-size: 11px; font-weight: bold; padding: 6px 10px; border-radius: 8px; cursor: pointer;">💾 全プリセットに保存</button>
    </div>

    <div style="display: flex; gap: 8px;">
      <button class="start-btn" style="flex: 2.8;" onclick="startAppWithFloating()">開始</button>
      <button class="start-btn" style="flex: 1.2; background: #DC2626;" onclick="stopFloatingOverlay()">🛑 終了</button>
    </div>
  </div>

  <!-- 4. Preset Management Modal -->
  <div class="modal-backdrop" id="presetModal">
    <div class="modal-card">
      <div class="modal-header">
        <div class="modal-title">🏷️ プリセット管理・編集</div>
        <button class="modal-close" onclick="closePresetModal()">✕</button>
      </div>

      <!-- Edit / Add Form -->
      <div class="preset-form">
        <div class="form-title">
          <span id="formTitleLabel">現在の時刻で新規登録</span>
          <span id="formTimeHint" style="color: #6355DE; font-family: monospace;">21:00:59.500</span>
        </div>
        <input type="text" class="form-input" id="presetTitleInput" placeholder="例: 木曜 ズンバ予約">
        
        <div class="time-input-row">
          <span>時刻指定:</span>
          <input type="number" id="formHourInput" class="time-sub-input" min="0" max="23" value="21">
          <span>:</span>
          <input type="number" id="formMinInput" class="time-sub-input" min="0" max="59" value="00">
          <span style="color: #64748B; font-weight: normal;">: 59 . 50 (固定)</span>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin: 8px 0 4px;">
          <span style="font-size: 11px; font-weight: bold; color: #475569;">🎯 ターゲット・目印の保存位置 (px):</span>
          <button type="button" onclick="applyLastCoordsToInputs()" style="padding: 3px 8px; font-size: 10px; background: #EDE9FE; color: #6D28D9; border: 1px solid #DDD6FE; border-radius: 6px; cursor: pointer; font-weight: bold;">📍 最新配置を自動反映</button>
        </div>
        <div style="display: flex; gap: 8px; margin-bottom: 8px; font-size: 11px;">
          <div style="flex: 1; background: #FAF5FF; padding: 6px; border-radius: 8px; border: 1px solid #E9D5FF;">
            <div style="font-weight: bold; color: #7C3AED; margin-bottom: 2px;">① 自動タップ位置</div>
            <div style="display: flex; gap: 4px; align-items: center;">
              X:<input type="number" id="formTarget1XInput" class="time-sub-input" style="width: 50px; font-size: 11px;" value="540">
              Y:<input type="number" id="formTarget1YInput" class="time-sub-input" style="width: 50px; font-size: 11px;" value="700">
            </div>
          </div>
          <div style="flex: 1; background: #F0F9FF; padding: 6px; border-radius: 8px; border: 1px solid #BAE6FD;">
            <div style="font-weight: bold; color: #0284C7; margin-bottom: 2px;">🎯 手動目印位置</div>
            <div style="display: flex; gap: 4px; align-items: center;">
              X:<input type="number" id="formGuideXInput" class="time-sub-input" style="width: 50px; font-size: 11px;" value="540">
              Y:<input type="number" id="formGuideYInput" class="time-sub-input" style="width: 50px; font-size: 11px;" value="1150">
            </div>
          </div>
        </div>

        <div class="form-btn-row">
          <button class="form-save-btn" id="formSaveBtn" onclick="handleSavePresetForm()">＋ 保存する</button>
          <button class="form-cancel-btn" id="formCancelBtn" style="display: none;" onclick="resetFormToAddMode()">キャンセル</button>
        </div>
      </div>

      <!-- Presets List -->
      <div style="font-size: 11px; font-weight: bold; color: #64748B; margin-bottom: 6px;">保存済みプリセット一覧</div>
      <div class="preset-list" id="modalPresetList">
        <!-- Rendered dynamically -->
      </div>
    </div>
  </div>

<script>
  let targetHour = 21;
  let targetMinute = 0;
  let targetSecond = 59;
  let targetMillisecond = 500;
  let activePresetId = 'preset-1';
  let presetName = '月曜 ヨガ予約';

  let hasOverlayPerm = false;
  let hasA11yPerm = false;
  let editingPresetId = null;

  // Initial Presets
  let presets = [
    { id: 'preset-1', name: '月曜 ヨガ予約', targetHour: 21, targetMinute: 0, targetSecond: 59, targetMillisecond: 500, targetX: 540, targetY: 700, guideX: 540, guideY: 1150 },
    { id: 'preset-2', name: '水曜 ピラティス', targetHour: 12, targetMinute: 0, targetSecond: 59, targetMillisecond: 500, targetX: 540, targetY: 750, guideX: 540, guideY: 1200 },
    { id: 'preset-3', name: '金曜 ダンス', targetHour: 19, targetMinute: 30, targetSecond: 59, targetMillisecond: 500, targetX: 540, targetY: 800, guideX: 540, guideY: 1250 },
    { id: 'preset-4', name: 'iTipness 朝07:00予約', targetHour: 6, targetMinute: 59, targetSecond: 59, targetMillisecond: 950, targetX: 540, targetY: 650, guideX: 540, guideY: 1100 }
  ];

  function loadPresets() {
    try {
      if (window.AndroidBridge && window.AndroidBridge.getPresetsJson) {
        const json = window.AndroidBridge.getPresetsJson();
        if (json) {
          const parsed = JSON.parse(json);
          if (Array.isArray(parsed) && parsed.length > 0) {
            presets = parsed;
          }
        }
        if (window.AndroidBridge.getLastSelectedPresetId) {
          const lastId = window.AndroidBridge.getLastSelectedPresetId();
          if (lastId && presets.some(p => p.id === lastId)) {
            activePresetId = lastId;
          }
        }
      } else {
        const local = localStorage.getItem('auto_click_presets_v2');
        if (local) {
          const parsed = JSON.parse(local);
          if (Array.isArray(parsed) && parsed.length > 0) presets = parsed;
        }
      }
    } catch (_) {}
    const cur = presets.find(p => p.id === activePresetId) || presets[0];
    if (cur) {
      selectPresetObj(cur);
    } else {
      renderPresetChips();
    }
    updateSavedPosLabel();
  }

  function renderPresetChips() {
    const bar = document.getElementById('presetsBar');
    // keep chip-add
    bar.innerHTML = '<button class="chip-add" onclick="openPresetModal(\'new\')">＋ 登録</button>';
    presets.forEach(p => {
      const btn = document.createElement('button');
      const isAct = p.id === activePresetId;
      btn.className = 'chip' + (isAct ? ' active' : '');
      const hStr = String(p.targetHour).padStart(2, '0');
      const mStr = String(p.targetMinute).padStart(2, '0');
      btn.innerHTML = '<span>' + escapeHtml(p.name) + '</span><span class="chip-time">' + hStr + ':' + mStr + '</span>';
      btn.onclick = () => selectPresetObj(p);
      bar.appendChild(btn);
    });
  }

  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, m => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[m]);
  }

  function selectPresetObj(p) {
    activePresetId = p.id;
    presetName = p.name;
    targetHour = p.targetHour;
    targetMinute = p.targetMinute;
    targetSecond = p.targetSecond || 59;
    targetMillisecond = p.targetMillisecond || 500;

    if (window.AndroidBridge && window.AndroidBridge.setLastSelectedPresetId) {
      window.AndroidBridge.setLastSelectedPresetId(p.id);
    }

    document.getElementById('currentPresetName').textContent = p.name;
    document.getElementById('cardPresetTag').textContent = p.name;
    renderValues();
    renderPresetChips();
  }

  function openPresetModal(mode) {
    const modal = document.getElementById('presetModal');
    modal.style.display = 'flex';
    if (mode === 'new') {
      resetFormToAddMode();
    } else {
      const act = presets.find(p => p.id === activePresetId);
      if (act) {
        startEditPreset(act.id);
      } else {
        resetFormToAddMode();
      }
    }
    renderModalPresetList();
  }

  function closePresetModal() {
    document.getElementById('presetModal').style.display = 'none';
  }

  function fetchLastCoords() {
    let coords = { target1X: 540, target1Y: 700, guideX: 540, guideY: 1150 };
    if (window.AndroidBridge && window.AndroidBridge.getLastSavedPositionsJson) {
      try {
        const json = window.AndroidBridge.getLastSavedPositionsJson();
        if (json) {
          const parsed = JSON.parse(json);
          if (parsed && parsed.target1X > 0) coords = parsed;
        }
      } catch (_) {}
    }
    return coords;
  }

  function updateSavedPosLabel() {
    const coords = fetchLastCoords();
    const lbl = document.getElementById('mainSavedPosLabel');
    if (lbl) {
      lbl.textContent = '①(' + coords.target1X + ', ' + coords.target1Y + ') / 🎯(' + coords.guideX + ', ' + coords.guideY + ')';
    }
  }

  function saveCurrentCoordsToAllPresets() {
    const coords = fetchLastCoords();
    if (window.AndroidBridge && window.AndroidBridge.updateAllPresetsCoordinates) {
      window.AndroidBridge.updateAllPresetsCoordinates(coords.target1X, coords.target1Y, coords.guideX, coords.guideY);
    }
    updateSavedPosLabel();
    loadPresets();
  }

  function applyLastCoordsToInputs() {
    const last = fetchLastCoords();
    if (document.getElementById('formTarget1XInput')) document.getElementById('formTarget1XInput').value = last.target1X;
    if (document.getElementById('formTarget1YInput')) document.getElementById('formTarget1YInput').value = last.target1Y;
    if (document.getElementById('formGuideXInput')) document.getElementById('formGuideXInput').value = last.guideX;
    if (document.getElementById('formGuideYInput')) document.getElementById('formGuideYInput').value = last.guideY;
    alert('📍 画面上の最新配置座標 ①(' + last.target1X + ', ' + last.target1Y + ') / 🎯(' + last.guideX + ', ' + last.guideY + ') をフォームに反映しました！');
  }

  function resetFormToAddMode() {
    editingPresetId = null;
    document.getElementById('formTitleLabel').textContent = '現在の時刻で新規登録';
    document.getElementById('presetTitleInput').value = '';
    document.getElementById('formHourInput').value = targetHour;
    document.getElementById('formMinInput').value = targetMinute;
    document.getElementById('formTimeHint').textContent = String(targetHour).padStart(2, '0') + ':' + String(targetMinute).padStart(2, '0') + ':59.500';
    const last = fetchLastCoords();
    if (document.getElementById('formTarget1XInput')) document.getElementById('formTarget1XInput').value = last.target1X;
    if (document.getElementById('formTarget1YInput')) document.getElementById('formTarget1YInput').value = last.target1Y;
    if (document.getElementById('formGuideXInput')) document.getElementById('formGuideXInput').value = last.guideX;
    if (document.getElementById('formGuideYInput')) document.getElementById('formGuideYInput').value = last.guideY;
    document.getElementById('formSaveBtn').textContent = '＋ 保存する';
    document.getElementById('formCancelBtn').style.display = 'none';
  }

  function startEditPreset(id) {
    const p = presets.find(x => x.id === id);
    if (!p) return;
    editingPresetId = id;
    document.getElementById('formTitleLabel').textContent = '✏️ プリセットを編集・名前変更';
    document.getElementById('presetTitleInput').value = p.name;
    document.getElementById('formHourInput').value = p.targetHour;
    document.getElementById('formMinInput').value = p.targetMinute;
    document.getElementById('formTimeHint').textContent = String(p.targetHour).padStart(2, '0') + ':' + String(p.targetMinute).padStart(2, '0') + ':59.500';
    const last = fetchLastCoords();
    if (document.getElementById('formTarget1XInput')) document.getElementById('formTarget1XInput').value = (p.targetX > 0 ? p.targetX : last.target1X);
    if (document.getElementById('formTarget1YInput')) document.getElementById('formTarget1YInput').value = (p.targetY > 0 ? p.targetY : last.target1Y);
    if (document.getElementById('formGuideXInput')) document.getElementById('formGuideXInput').value = (p.guideX > 0 ? p.guideX : last.guideX);
    if (document.getElementById('formGuideYInput')) document.getElementById('formGuideYInput').value = (p.guideY > 0 ? p.guideY : last.guideY);
    document.getElementById('formSaveBtn').textContent = '💾 更新を保存';
    document.getElementById('formCancelBtn').style.display = 'block';
  }

  function handleSavePresetForm() {
    const title = document.getElementById('presetTitleInput').value.trim();
    if (!title) {
      alert('プリセット名を入力してください');
      return;
    }
    const h = parseInt(document.getElementById('formHourInput').value) || 0;
    const m = parseInt(document.getElementById('formMinInput').value) || 0;
    const s = 59;
    const ms = 500;
    const t1X = parseInt(document.getElementById('formTarget1XInput')?.value) || 540;
    const t1Y = parseInt(document.getElementById('formTarget1YInput')?.value) || 700;
    const gX = parseInt(document.getElementById('formGuideXInput')?.value) || 540;
    const gY = parseInt(document.getElementById('formGuideYInput')?.value) || 1150;

    let targetId = editingPresetId || '';
    if (window.AndroidBridge && window.AndroidBridge.savePreset) {
      targetId = window.AndroidBridge.savePreset(editingPresetId || '', title, h, m, s, ms, t1X, t1Y, gX, gY);
      try {
        const json = window.AndroidBridge.getPresetsJson();
        if (json) presets = JSON.parse(json);
      } catch (_) {}
    } else {
      if (editingPresetId) {
        const idx = presets.findIndex(x => x.id === editingPresetId);
        if (idx >= 0) {
          presets[idx] = { id: editingPresetId, name: title, targetHour: h, targetMinute: m, targetSecond: s, targetMillisecond: ms, targetX: t1X, targetY: t1Y, guideX: gX, guideY: gY };
        }
      } else {
        const newP = { id: 'preset-' + Date.now(), name: title, targetHour: h, targetMinute: m, targetSecond: s, targetMillisecond: ms, targetX: t1X, targetY: t1Y, guideX: gX, guideY: gY };
        presets.push(newP);
        targetId = newP.id;
      }
    }

    try {
      localStorage.setItem('auto_click_presets_v2', JSON.stringify(presets));
    } catch (_) {}

    const selected = presets.find(x => x.id === targetId) || presets[presets.length - 1];
    selectPresetObj(selected);
    closePresetModal();
  }

  function handleDeletePreset(id) {
    if (presets.length <= 1) {
      alert('最低1つのプリセットが必要です');
      return;
    }
    if (window.AndroidBridge && window.AndroidBridge.deletePreset) {
      window.AndroidBridge.deletePreset(id);
      try {
        const json = window.AndroidBridge.getPresetsJson();
        if (json) presets = JSON.parse(json);
      } catch (_) {}
    } else {
      presets = presets.filter(x => x.id !== id);
    }
    try {
      localStorage.setItem('auto_click_presets_v2', JSON.stringify(presets));
    } catch (_) {}

    if (activePresetId === id) {
      selectPresetObj(presets[0]);
    }
    renderPresetChips();
    renderModalPresetList();
    if (editingPresetId === id) {
      resetFormToAddMode();
    }
  }

  function renderModalPresetList() {
    const list = document.getElementById('modalPresetList');
    list.innerHTML = '';
    presets.forEach(p => {
      const item = document.createElement('div');
      const isAct = p.id === activePresetId;
      item.className = 'preset-item' + (isAct ? ' active' : '');
      const timeStr = String(p.targetHour).padStart(2, '0') + ':' + String(p.targetMinute).padStart(2, '0') + ':59.500';

      item.innerHTML = 
        '<div class="preset-info" onclick="selectAndCloseModal(\'' + p.id + '\')">' +
          '<div class="preset-name">' + (isAct ? '✓ ' : '') + escapeHtml(p.name) + '</div>' +
          '<div class="preset-timing">' + timeStr + ' · ①(' + (p.targetX || 540) + ',' + (p.targetY || 700) + ') 🎯(' + (p.guideX || 540) + ',' + (p.guideY || 1150) + ')</div>' +
        '</div>' +
        '<div class="preset-actions">' +
          '<button class="action-btn" title="名前・時間を編集" onclick="startEditPreset(\'' + p.id + '\')">✏️</button>' +
          '<button class="action-btn del" title="削除" onclick="handleDeletePreset(\'' + p.id + '\')">🗑️</button>' +
        '</div>';
      list.appendChild(item);
    });
  }

  function selectAndCloseModal(id) {
    const p = presets.find(x => x.id === id);
    if (p) selectPresetObj(p);
    closePresetModal();
  }

  function updatePermissions(overlay, a11y) {
    hasOverlayPerm = overlay;
    hasA11yPerm = a11y;
    const box = document.getElementById('permBox');
    const msg = document.getElementById('permMsg');
    const btn = document.getElementById('permActionBtn');

    if (!overlay) {
      box.style.display = 'block';
      msg.textContent = '⚠️ 他アプリの上に重ねて表示する権限を許可してください';
      btn.textContent = '最前面表示を許可';
    } else if (!a11y) {
      box.style.display = 'block';
      msg.textContent = '⚠️ 自動タップ用の「ユーザー補助」をONにしてください';
      btn.textContent = 'ユーザー補助を有効化';
    } else {
      box.style.display = 'none';
    }
  }

  function handlePermAction() {
    if (!hasOverlayPerm) {
      AndroidBridge.requestOverlayPermission();
    } else if (!hasA11yPerm) {
      AndroidBridge.requestAccessibilityPermission();
    }
  }

  function renderValues() {
    document.getElementById('hourInput').value = String(targetHour).padStart(2, '0');
    document.getElementById('minInput').value = String(targetMinute).padStart(2, '0');
    document.getElementById('secVal').textContent = String(targetSecond).padStart(2, '0');

    document.getElementById('hGhostUp').textContent = String((targetHour + 23) % 24).padStart(2, '0');
    document.getElementById('hGhostDown').textContent = String((targetHour + 1) % 24).padStart(2, '0');

    document.getElementById('mGhostUp').textContent = String((targetMinute + 59) % 60).padStart(2, '0');
    document.getElementById('mGhostDown').textContent = String((targetMinute + 1) % 60).padStart(2, '0');

    document.getElementById('summaryTime').innerHTML = 
      String(targetHour).padStart(2, '0') + ' : ' + 
      String(targetMinute).padStart(2, '0') + ' : ' + 
      String(targetSecond).padStart(2, '0') + ' <span>.' + String(targetMillisecond).padStart(3, '0') + '</span>';
  }

  function adjHour(delta) {
    targetHour = (targetHour + delta + 24) % 24;
    renderValues();
  }

  function adjMin(delta) {
    targetMinute = (targetMinute + delta + 60) % 60;
    renderValues();
  }

  function syncFromInput() {
    let h = parseInt(document.getElementById('hourInput').value) || 0;
    let m = parseInt(document.getElementById('minInput').value) || 0;
    targetHour = Math.max(0, Math.min(23, h));
    targetMinute = Math.max(0, Math.min(59, m));
    renderValues();
  }

  function setNowTime() {
    const d = new Date();
    targetHour = d.getHours();
    targetMinute = d.getMinutes();
    renderValues();
  }

  function addMins(mins) {
    targetMinute = (targetMinute + mins) % 60;
    if (targetMinute < mins) {
      targetHour = (targetHour + 1) % 24;
    }
    renderValues();
  }

  function startAppWithFloating() {
    // Pass -1 to automatically inherit and retain the user's previous saved positions!
    if (window.AndroidBridge && window.AndroidBridge.startFloatingService) {
      window.AndroidBridge.startFloatingService(targetHour, targetMinute, targetSecond, targetMillisecond, presetName, true, -1, -1, -1, -1);
    } else {
      alert('Androidアプリ環境で最前面フローティングが起動します');
    }
  }

  function stopFloatingOverlay() {
    if (window.AndroidBridge && window.AndroidBridge.stopFloatingService) {
      window.AndroidBridge.stopFloatingService();
    }
  }

  // Ticker for Countdown
  setInterval(() => {
    const now = new Date();
    const target = new Date(now);
    target.setHours(targetHour, targetMinute, targetSecond, targetMillisecond);
    if (target.getTime() <= now.getTime()) {
      target.setDate(target.getDate() + 1);
    }
    const diff = Math.max(0, target.getTime() - now.getTime());
    const s = Math.floor(diff / 1000);
    const hrs = String(Math.floor(s / 3600)).padStart(2, '0');
    const mins = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const secs = String(s % 60).padStart(2, '0');
    document.getElementById('countdownLabel').textContent = hrs + ':' + mins + ':' + secs;
  }, 500);

  loadPresets();
  renderValues();
</script>
</body>
</html>
        """.trimIndent()

        webView.loadDataWithBaseURL("https://autoclicker.local/", html, "text/html", "UTF-8", null)
    }
}
