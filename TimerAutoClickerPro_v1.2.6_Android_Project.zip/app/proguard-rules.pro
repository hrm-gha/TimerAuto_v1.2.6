# Proguard rules for Timer Auto Clicker
-keep class com.autoclicker.timer.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
