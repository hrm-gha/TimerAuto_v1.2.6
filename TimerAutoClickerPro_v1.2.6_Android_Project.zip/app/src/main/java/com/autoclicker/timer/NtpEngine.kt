package com.autoclicker.timer

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.URL

data class NtpResult(
    val offsetMs: Long,
    val rttMs: Long,
    val serverTimeMs: Long
)

object NtpEngine {
    private const val NTP_HOST = "ntp.nict.jp" // 日本標準時 (NICT)
    private const val NTP_PORT = 123
    private const val TIMEOUT_MS = 3000

    @Volatile
    var currentOffsetMs: Long = 0L
        private set

    @Volatile
    var lastSyncRealtimeNanos: Long = 0L
        private set

    /**
     * Get current accurate NTP-synchronized epoch milliseconds
     */
    fun getAccurateTimeMs(): Long {
        val nowLocal = System.currentTimeMillis()
        return nowLocal + currentOffsetMs
    }

    /**
     * Synchronize time with NTP server using UDP SNTP protocol
     * Falls back to Cloudflare HTTPS Cristian's algorithm if UDP is blocked by cellular carrier
     */
    suspend fun syncTime(): NtpResult = withContext(Dispatchers.IO) {
        try {
            val result = queryUdpNtp(NTP_HOST)
            currentOffsetMs = result.offsetMs
            lastSyncRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            result
        } catch (e: Exception) {
            // Cellular networks sometimes block UDP port 123 -> fallback to HTTPS
            val fallback = queryHttpsNtp("https://1.1.1.1/cdn-cgi/trace")
            currentOffsetMs = fallback.offsetMs
            lastSyncRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            fallback
        }
    }

    private fun queryUdpNtp(host: String): NtpResult {
        val socket = DatagramSocket()
        socket.soTimeout = TIMEOUT_MS
        val address = InetAddress.getByName(host)

        val buffer = ByteArray(48)
        buffer[0] = 0b00100011 // LI=0, VN=4, Mode=3 (Client)

        val requestPacket = DatagramPacket(buffer, buffer.size, address, NTP_PORT)
        val t0 = System.currentTimeMillis()
        val p0 = SystemClock.elapsedRealtime()

        socket.send(requestPacket)

        val responsePacket = DatagramPacket(buffer, buffer.size)
        socket.receive(responsePacket)

        val p1 = SystemClock.elapsedRealtime()
        val t3 = System.currentTimeMillis()
        val rtt = (p1 - p0)

        socket.close()

        // Extract transmit timestamp (bytes 40-47)
        var seconds = 0L
        for (i in 40..43) {
            seconds = (seconds shl 8) or (buffer[i].toLong() and 0xFF)
        }
        var fraction = 0L
        for (i in 44..47) {
            fraction = (fraction shl 8) or (buffer[i].toLong() and 0xFF)
        }

        // Convert NTP time (epoch 1900) to Unix epoch (1970)
        val ntpEpochOffset = 2208988800L
        val unixSeconds = seconds - ntpEpochOffset
        val millis = (fraction * 1000) / 0x100000000L
        val tServer = (unixSeconds * 1000) + millis

        // Cristian's estimate: estimated server now = tServer + (rtt / 2)
        val estimatedServerNow = tServer + (rtt / 2)
        val offset = estimatedServerNow - t3

        return NtpResult(offset, rtt, estimatedServerNow)
    }

    private fun queryHttpsNtp(urlStr: String): NtpResult {
        val p0 = SystemClock.elapsedRealtime()
        val t0 = System.currentTimeMillis()

        val connection = URL("$urlStr?_t=$t0").openConnection()
        connection.connectTimeout = 3000
        connection.readTimeout = 3000
        val text = connection.getInputStream().bufferedReader().readText()

        val p1 = SystemClock.elapsedRealtime()
        val tEnd = System.currentTimeMillis()
        val rtt = Math.max(1, p1 - p0)

        // Parse "ts=1726410000.123"
        val match = Regex("ts=(\\d+(?:\\.\\d+)?)").find(text)
            ?: throw IllegalStateException("Could not parse timestamp from Cloudflare")

        val serverSec = match.groupValues[1].toDouble()
        val serverMs = Math.round(serverSec * 1000)

        val estimatedServerNow = serverMs + (rtt / 2)
        val offset = estimatedServerNow - tEnd

        return NtpResult(offset, rtt, estimatedServerNow)
    }
}
