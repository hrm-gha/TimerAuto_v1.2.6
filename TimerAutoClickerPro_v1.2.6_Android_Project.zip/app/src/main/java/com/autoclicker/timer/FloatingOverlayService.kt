package com.autoclicker.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.Calendar

class FloatingOverlayService : Service() {

    private lateinit var defaultWindowManager: WindowManager
    private lateinit var presetRepo: PresetRepository
    private var vibrator: Vibrator? = null

    companion object {
        var instance: FloatingOverlayService? = null
            private set
        const val ACTION_STOP = "com.autoclicker.timer.ACTION_STOP"
        const val EXTRA_HOUR = "extra_hour"
        const val EXTRA_MINUTE = "extra_minute"
        const val EXTRA_SECOND = "extra_second"
        const val EXTRA_MILLISECOND = "extra_millisecond"
        const val EXTRA_ARMED = "extra_armed"
        const val EXTRA_PRESET_NAME = "extra_preset_name"
        const val EXTRA_PRESET_ID = "extra_preset_id"
        const val EXTRA_TARGET1_X = "extra_target1_x"
        const val EXTRA_TARGET1_Y = "extra_target1_y"
        const val EXTRA_GUIDE_X = "extra_guide_x"
        const val EXTRA_GUIDE_Y = "extra_guide_y"
        private const val TARGET_SIZE_DP = 64f
        private const val GUIDE_SIZE_DP = 56f
    }

    private fun dpToPx(dp: Float): Int {
        return (dp * resources.displayMetrics.density + 0.5f).toInt()
    }

    private val targetSizePx: Int get() = dpToPx(TARGET_SIZE_DP)
    private val targetRadiusPx: Int get() = targetSizePx / 2
    private val guideSizePx: Int get() = dpToPx(GUIDE_SIZE_DP)
    private val guideRadiusPx: Int get() = guideSizePx / 2

    // 1. Target 1: Auto-Click Target Coordinates [ 1 ] (Aimed at Click Assistant triangle play button)
    private var target1X = 540
    private var target1Y = 700

    // 2. Target 2: Manual Tap Guide Coordinates [ 🎯 ] (Aimed at target studio/seat slot button)
    private var guideX = 540
    private var guideY = 1150

    // Tap duration for Target 1 (40ms: reliable hardware-equivalent physical tap)
    private var tapDurationMs = 40L

    // Unified Lock / Move State
    // When true: BOTH Target 1 and Guide 2 have FLAG_NOT_TOUCHABLE
    // -> Neither intercepts touches; clicks pass 100% straight through to Click Assistant and website buttons!
    // When false: both can be dragged to position
    private var isTargetsLocked = true
    private var target1LayoutParams: WindowManager.LayoutParams? = null
    private var guideLayoutParams: WindowManager.LayoutParams? = null
    private var hudLayoutParams: WindowManager.LayoutParams? = null

    // Target Views
    private var target1View: View? = null
    private var guideView: View? = null
    private var hudView: View? = null
    private var settingsOverlayView: View? = null

    // Standalone floating mini-clock pill (User can drag this anywhere on screen)
    private var isFloatingClockVisible = false
    private var floatingClockView: View? = null
    private var floatingClockLayoutParams: WindowManager.LayoutParams? = null
    private var floatingClockWm: WindowManager? = null
    private var floatingClockText: TextView? = null
    private var floatingClockX = 60
    private var floatingClockY = 120

    // Guide subviews
    private var guideOuterRing: View? = null
    private var guideApertureRing: View? = null
    private var guideBadgeText: TextView? = null

    // WindowManagers
    private var target1Wm: WindowManager? = null
    private var guideWm: WindowManager? = null
    private var hudWm: WindowManager? = null
    private var settingsWm: WindowManager? = null

    // Schedule state
    private var isArmed = true
    private var isExecuted = false
    private var executedTimeStr: String? = null
    private var currentPresetTitle = "月曜 ヨガ予約"

    // Target Time (Defaults to 21:00:59.50)
    private var targetHour = 21
    private var targetMinute = 0
    private var targetSecond = 59
    private var targetMillisecond = 500

    // HUD child references
    private var statusBadge: TextView? = null
    private var hudAtomicClockText: TextView? = null
    private var countdownText: TextView? = null
    private var lockToggleBtn: Button? = null
    private var armToggleBtn: Button? = null
    private var floatingClockBtn: Button? = null

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var timerJob: Job? = null

    // Touch interaction lock
    private var isDragging = false

    // Countdown vibration cues
    private var buzz3sDone = false
    private var buzz2sDone = false
    private var buzz1sDone = false

    private var a11yWindowContext: Context? = null
    private var a11yWindowManager: WindowManager? = null

    private fun getOverlayLayoutFlag(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun getAccessibilityWindowManager(): WindowManager? {
        val a11y = AutoClickAccessibilityService.instance ?: return null
        if (a11yWindowManager != null) return a11yWindowManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val displayManager = a11y.getSystemService(Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager
                val display = displayManager?.getDisplay(android.view.Display.DEFAULT_DISPLAY)
                val baseContext = if (display != null) a11y.createDisplayContext(display) else a11y
                val winCtx = baseContext.createWindowContext(
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    null
                )
                a11yWindowContext = winCtx
                a11yWindowManager = winCtx.getSystemService(WindowManager::class.java)
                Log.d("FloatingOverlay", "Successfully created WindowContext for TYPE_ACCESSIBILITY_OVERLAY with display context")
                return a11yWindowManager
            } catch (e: Exception) {
                Log.w("FloatingOverlay", "createWindowContext with display failed: ${e.message}")
            }
        }

        try {
            a11yWindowManager = a11y.getSystemService(WINDOW_SERVICE) as? WindowManager
            return a11yWindowManager
        } catch (e: Exception) {
            Log.e("FloatingOverlay", "Failed to get accessibility window manager", e)
            return null
        }
    }

    private fun getBestWindowManager(): Pair<WindowManager, Int> {
        val wm = getAccessibilityWindowManager()
        if (wm != null) {
            return Pair(wm, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        }
        return Pair(defaultWindowManager, getOverlayLayoutFlag())
    }

    private fun getOverlayContext(): Context {
        return a11yWindowContext ?: AutoClickAccessibilityService.instance ?: this
    }

    private fun safeReAddView(wm: WindowManager, view: View, params: WindowManager.LayoutParams) {
        try {
            wm.removeViewImmediate(view)
        } catch (_: Exception) {}
        try {
            defaultWindowManager.removeViewImmediate(view)
        } catch (_: Exception) {}

        try {
            wm.addView(view, params)
        } catch (e: Exception) {
            Log.w("FloatingOverlay", "safeReAddView addView with primary wm failed: ${e.message}, falling back to defaultWindowManager")
            try {
                params.type = getOverlayLayoutFlag()
                defaultWindowManager.addView(view, params)
            } catch (e2: Exception) {
                Log.e("FloatingOverlay", "safeReAddView fallback failed: ${e2.message}")
            }
        }
    }

    private fun addOverlayViewSafe(
        view: View,
        params: WindowManager.LayoutParams
    ): WindowManager {
        val a11yWm = getAccessibilityWindowManager()
        if (a11yWm != null) {
            try {
                params.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                a11yWm.addView(view, params)
                Log.d("FloatingOverlay", "Added view as TYPE_ACCESSIBILITY_OVERLAY (Layer 22, above Click Assistant)")
                return a11yWm
            } catch (e: Exception) {
                Log.w("FloatingOverlay", "Failed to add as TYPE_ACCESSIBILITY_OVERLAY, falling back: ${e.message}")
            }
        }

        // Fallback: TYPE_APPLICATION_OVERLAY (layer 20)
        params.type = getOverlayLayoutFlag()
        try {
            defaultWindowManager.addView(view, params)
            Log.d("FloatingOverlay", "Added view as TYPE_APPLICATION_OVERLAY")
        } catch (e: Exception) {
            Log.e("FloatingOverlay", "Failed to add view with defaultWindowManager", e)
        }
        return defaultWindowManager
    }

    fun bringAllToFront(showToast: Boolean = false) {
        if (isDragging) return
        val targetWm = target1Wm ?: a11yWindowManager ?: defaultWindowManager
        val guideWmCurrent = guideWm ?: a11yWindowManager ?: defaultWindowManager
        val hudWmCurrent = hudWm ?: a11yWindowManager ?: defaultWindowManager

        // 1. Re-add Guide 2
        guideView?.let { v ->
            guideLayoutParams?.let { p ->
                safeReAddView(guideWmCurrent, v, p)
            }
        }

        // 2. Re-add Target 1 (on top of background/guide)
        target1View?.let { v ->
            target1LayoutParams?.let { p ->
                safeReAddView(targetWm, v, p)
            }
        }

        // 3. Re-add Floating Standalone Clock (if visible)
        if (isFloatingClockVisible) {
            floatingClockView?.let { v ->
                floatingClockLayoutParams?.let { p ->
                    safeReAddView(floatingClockWm ?: defaultWindowManager, v, p)
                }
            }
        }

        // 4. Re-add HUD (always accessible on top)
        hudView?.let { v ->
            val p = v.layoutParams as? WindowManager.LayoutParams
            if (p != null) {
                safeReAddView(hudWmCurrent, v, p)
            }
        }

        if (showToast) {
            doVibrate(20)
            Toast.makeText(this, "🔝 ターゲットとHUDを最前面に再配置しました", Toast.LENGTH_SHORT).show()
        }
    }

    fun promoteToAccessibilityOverlay() {
        if (isDragging) return
        val a11yWm = getAccessibilityWindowManager() ?: return
        try {
            // Guide 2: Manual Slot Guide Marker
            guideView?.let { v ->
                guideLayoutParams?.let { p ->
                    p.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    safeReAddView(a11yWm, v, p)
                    guideWm = a11yWm
                }
            }

            // Target 1: Auto-Click Ring
            target1View?.let { v ->
                target1LayoutParams?.let { p ->
                    p.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    safeReAddView(a11yWm, v, p)
                    target1Wm = a11yWm
                }
            }

            // Floating Standalone Clock (if visible)
            if (isFloatingClockVisible) {
                floatingClockView?.let { v ->
                    floatingClockLayoutParams?.let { p ->
                        p.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                        safeReAddView(a11yWm, v, p)
                        floatingClockWm = a11yWm
                    }
                }
            }

            // Floating Top HUD
            hudView?.let { v ->
                val p = v.layoutParams as? WindowManager.LayoutParams
                if (p != null) {
                    p.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    safeReAddView(a11yWm, v, p)
                    hudWm = a11yWm
                }
            }
            Log.d("FloatingOverlay", "Promoted all overlays to TYPE_ACCESSIBILITY_OVERLAY (Top-most)")
        } catch (e: Exception) {
            Log.e("FloatingOverlay", "Failed to promote overlays to TYPE_ACCESSIBILITY_OVERLAY", e)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        defaultWindowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        presetRepo = PresetRepository(this)
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

        // Preemptively remove any orphaned/existing views to prevent bar duplication
        removeAllViews()

        startForegroundNotification()

        val displayMetrics = resources.displayMetrics
        val savedCoords = presetRepo.getLastCoordinates()
        if (savedCoords != null) {
            target1X = savedCoords.target1X
            target1Y = savedCoords.target1Y
            guideX = savedCoords.guideX
            guideY = savedCoords.guideY
        } else {
            target1X = displayMetrics.widthPixels / 2
            target1Y = (displayMetrics.heightPixels * 0.35).toInt()
            guideX = displayMetrics.widthPixels / 2
            guideY = (displayMetrics.heightPixels * 0.58).toInt()
        }

        val savedClock = presetRepo.getClockState()
        if (savedClock != null) {
            floatingClockX = savedClock.first
            floatingClockY = savedClock.second
        } else {
            floatingClockX = dpToPx(16f)
            floatingClockY = dpToPx(110f)
        }

        val savedTime = presetRepo.getLastTargetTime()
        if (savedTime != null) {
            targetHour = savedTime[0]
            targetMinute = savedTime[1]
            targetSecond = savedTime[2]
            targetMillisecond = savedTime[3]
        }

        createTarget1View() // ① 自動クリックターゲット [ 1 ]
        createGuide2View()   // 🎯 手動タップ用目印ガイド [ 🎯 ]
        createTopFloatingHud()

        if (savedClock?.third == true) {
            toggleFloatingClock(true)
        }

        // Apply default locked (pass-through) mode so neither target blocks touches!
        setTargetsLocked(true, showToast = false)
        promoteToAccessibilityOverlay()
        bringAllToFront(showToast = false)

        serviceScope.launch(Dispatchers.IO) {
            try {
                NtpEngine.syncTime()
            } catch (_: Exception) {}
        }

        startCountdownTicker()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Toast.makeText(this, "あたり！予約成功クリッカー を終了しました", Toast.LENGTH_SHORT).show()
            removeAllViewsAndStop()
            return START_NOT_STICKY
        }

        if (intent != null) {
            val h = intent.getIntExtra(EXTRA_HOUR, -1)
            val m = intent.getIntExtra(EXTRA_MINUTE, -1)
            val s = intent.getIntExtra(EXTRA_SECOND, -1)
            val ms = intent.getIntExtra(EXTRA_MILLISECOND, -1)
            val arm = intent.getBooleanExtra(EXTRA_ARMED, true)
            val pName = intent.getStringExtra(EXTRA_PRESET_NAME)
            val pId = intent.getStringExtra(EXTRA_PRESET_ID)
            val customT1X = intent.getIntExtra(EXTRA_TARGET1_X, -1)
            val customT1Y = intent.getIntExtra(EXTRA_TARGET1_Y, -1)
            val customGX = intent.getIntExtra(EXTRA_GUIDE_X, -1)
            val customGY = intent.getIntExtra(EXTRA_GUIDE_Y, -1)

            if (h in 0..23) targetHour = h
            if (m in 0..59) targetMinute = m
            if (s in 0..59) targetSecond = s
            if (ms in 0..999) targetMillisecond = ms
            if (!pName.isNullOrBlank()) currentPresetTitle = pName

            // Check if user has a saved last position (前回の最終位置を引き継ぎ)
            val savedLast = presetRepo.getLastCoordinates()
            if (savedLast != null) {
                target1X = savedLast.target1X
                target1Y = savedLast.target1Y
                guideX = savedLast.guideX
                guideY = savedLast.guideY
            } else if (!pName.isNullOrBlank() || !pId.isNullOrBlank()) {
                val matched = presetRepo.getAllPresets().find { it.name == pName || it.id == pId }
                if (matched != null) {
                    if (matched.targetX > 0) target1X = matched.targetX
                    if (matched.targetY > 0) target1Y = matched.targetY
                    if (matched.guideX > 0) guideX = matched.guideX
                    if (matched.guideY > 0) guideY = matched.guideY
                }
            }

            // Only override if intent explicitly passes non-negative custom coordinates
            if (customT1X > 0 && customT1Y > 0) {
                target1X = customT1X
                target1Y = customT1Y
            }
            if (customGX > 0 && customGY > 0) {
                guideX = customGX
                guideY = customGY
            }

            applyTargetPositionsToViews()
            saveCurrentPositionsAndSettings(false)

            isArmed = arm
            isExecuted = false
            executedTimeStr = null
            resetBuzzFlags()
            updateArmButtonState()
            updateStatusBadge()
            promoteToAccessibilityOverlay()
            bringAllToFront(showToast = false)
        }

        return START_STICKY
    }

    private fun resetBuzzFlags() {
        buzz3sDone = false
        buzz2sDone = false
        buzz1sDone = false
    }

    private fun startForegroundNotification() {
        val channelId = "timer_auto_clicker_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "あたり！予約成功クリッカー",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            101,
            stopIntent,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("あたり！予約成功クリッカー (原子時計一体化)")
            .setContentText("①自動タップ + 🎯手動目印 + ⏱️原子時計 | 目標: ${formatTargetTimeStr()}")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "🛑 終了", stopPendingIntent)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    /**
     * ① Target 1: Auto-Click Target [ 1 ]
     * Placed over Click Assistant's start triangle icon (▶).
     * When locked, MUST have FLAG_NOT_TOUCHABLE so it does NOT absorb touches.
     */
    private fun createTarget1View() {
        val (wm, layoutFlag) = getBestWindowManager()
        target1Wm = wm

        val size = targetSizePx
        var initialFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        if (isTargetsLocked) {
            initialFlags = initialFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        val params = WindowManager.LayoutParams(
            size, size,
            layoutFlag,
            initialFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = target1X - targetRadiusPx
            y = target1Y - targetRadiusPx
        }
        target1LayoutParams = params

        val ctx = getOverlayContext()
        val targetCard = FrameLayout(ctx).apply {
            // Outer ring (64dp) with luminous neon purple border
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#458B5CF6")) // Luminous translucent purple
                setStroke(dpToPx(3.5f), Color.parseColor("#C084FC")) // High-contrast neon violet stroke
            }

            // Crosshair H
            addView(View(context).apply {
                setBackgroundColor(Color.parseColor("#F3E8FF"))
                layoutParams = FrameLayout.LayoutParams(-1, dpToPx(1.5f)).apply { gravity = Gravity.CENTER }
            })
            // Crosshair V
            addView(View(context).apply {
                setBackgroundColor(Color.parseColor("#F3E8FF"))
                layoutParams = FrameLayout.LayoutParams(dpToPx(1.5f), -1).apply { gravity = Gravity.CENTER }
            })

            // Center Pinpoint Dot (14dp)
            addView(View(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#7C3AED"))
                    setStroke(dpToPx(2f), Color.WHITE)
                }
                layoutParams = FrameLayout.LayoutParams(dpToPx(14f), dpToPx(14f)).apply { gravity = Gravity.CENTER }
            })

            // Badge [ 1 ] on Corner
            addView(TextView(context).apply {
                text = "1"
                setTextColor(Color.WHITE)
                textSize = 10.5f
                paint.isFakeBoldText = true
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#6355DE"))
                    setStroke(dpToPx(1.5f), Color.WHITE)
                }
                layoutParams = FrameLayout.LayoutParams(dpToPx(20f), dpToPx(20f)).apply {
                    gravity = Gravity.TOP or Gravity.END
                }
            })
        }

        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f
        targetCard.setOnTouchListener { view, event ->
            if (isTargetsLocked) return@setOnTouchListener false

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = true
                    initX = params.x; initY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    isDragging = true
                    params.x = initX + (event.rawX - touchX).toInt()
                    params.y = initY + (event.rawY - touchY).toInt()
                    target1X = params.x + targetRadiusPx
                    target1Y = params.y + targetRadiusPx
                    try { (target1Wm ?: defaultWindowManager).updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    isDragging = false
                    target1X = params.x + targetRadiusPx
                    target1Y = params.y + targetRadiusPx
                    saveCurrentPositionsAndSettings(false)
                    updateStatusBadge()
                    doVibrate(15)
                    Toast.makeText(this@FloatingOverlayService, "① 位置保存: ($target1X, $target1Y)", Toast.LENGTH_SHORT).show()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    isDragging = false
                    false
                }
                else -> false
            }
        }

        target1View = targetCard
        target1Wm = addOverlayViewSafe(targetCard, params)
    }

    /**
     * 🎯 Target 2: Manual Tap Guide Marker [ 🎯 ]
     * Placed over the slot button (site-specific, e.g. 9 or any number).
     * Features:
     * - Transparent center aperture (26dp hollow ring + crosshairs)
     * - Touch pass-through (FLAG_NOT_TOUCHABLE)
     * - Minimal compact badge (🔒 vs ✋)
     */
    private fun createGuide2View() {
        val (wm, layoutFlag) = getBestWindowManager()
        guideWm = wm

        val size = guideSizePx
        var initialFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        if (isTargetsLocked) {
            initialFlags = initialFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        val params = WindowManager.LayoutParams(
            size, size,
            layoutFlag,
            initialFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = guideX - guideRadiusPx
            y = guideY - guideRadiusPx
        }
        guideLayoutParams = params

        val ctx = getOverlayContext()
        val guideCard = FrameLayout(ctx)

        // 1. Outer Ring (52dp)
        val outerRing = View(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(dpToPx(52f), dpToPx(52f)).apply {
                gravity = Gravity.CENTER
            }
        }
        guideOuterRing = outerRing
        guideCard.addView(outerRing)

        // 2. Reticle Ticks (Pointing to center aperture)
        guideCard.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#38BDF8"))
            layoutParams = FrameLayout.LayoutParams(dpToPx(1.5f), dpToPx(10f)).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = dpToPx(3f)
            }
        })
        guideCard.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#38BDF8"))
            layoutParams = FrameLayout.LayoutParams(dpToPx(1.5f), dpToPx(10f)).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dpToPx(3f)
            }
        })
        guideCard.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#38BDF8"))
            layoutParams = FrameLayout.LayoutParams(dpToPx(10f), dpToPx(1.5f)).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                leftMargin = dpToPx(3f)
            }
        })
        guideCard.addView(View(ctx).apply {
            setBackgroundColor(Color.parseColor("#38BDF8"))
            layoutParams = FrameLayout.LayoutParams(dpToPx(10f), dpToPx(1.5f)).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                rightMargin = dpToPx(3f)
            }
        })

        // 3. Clear Center Aperture Ring (26dp hollow ring: slot button is 100% visible inside!)
        val apertureRing = View(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(dpToPx(26f), dpToPx(26f)).apply {
                gravity = Gravity.CENTER
            }
        }
        guideApertureRing = apertureRing
        guideCard.addView(apertureRing)

        // 4. Center micro dot
        guideCard.addView(View(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
            }
            layoutParams = FrameLayout.LayoutParams(dpToPx(2.5f), dpToPx(2.5f)).apply {
                gravity = Gravity.CENTER
            }
        })

        // 5. Minimal Compact Badge (Only 🔒 or ✋)
        val badge = TextView(ctx).apply {
            textSize = 10f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setSingleLine(true)
            includeFontPadding = false
            setPadding(dpToPx(5f), dpToPx(1.5f), dpToPx(5f), dpToPx(1.5f))
            layoutParams = FrameLayout.LayoutParams(-2, -2).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
            setOnClickListener {
                setTargetsLocked(!isTargetsLocked)
            }
        }
        guideBadgeText = badge
        guideCard.addView(badge)

        updateGuideVisuals()

        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f
        guideCard.setOnTouchListener { view, event ->
            if (isTargetsLocked) return@setOnTouchListener false

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isDragging = true
                    initX = params.x; initY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    isDragging = true
                    params.x = initX + (event.rawX - touchX).toInt()
                    params.y = initY + (event.rawY - touchY).toInt()
                    guideX = params.x + guideRadiusPx
                    guideY = params.y + guideRadiusPx
                    try { (guideWm ?: defaultWindowManager).updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    isDragging = false
                    guideX = params.x + guideRadiusPx
                    guideY = params.y + guideRadiusPx
                    saveCurrentPositionsAndSettings(false)
                    updateStatusBadge()
                    doVibrate(15)
                    Toast.makeText(this@FloatingOverlayService, "🎯 位置保存: ($guideX, $guideY)", Toast.LENGTH_SHORT).show()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    isDragging = false
                    false
                }
                else -> false
            }
        }

        guideView = guideCard
        guideWm = addOverlayViewSafe(guideCard, params)
    }

    /**
     * Unified Lock / Move Toggle:
     */
    fun setTargetsLocked(locked: Boolean, showToast: Boolean = true) {
        isTargetsLocked = locked

        // Target 1
        target1LayoutParams?.let { p ->
            if (locked) {
                p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            try { (target1Wm ?: defaultWindowManager).updateViewLayout(target1View, p) } catch (_: Exception) {}
        }

        // Guide 2
        guideLayoutParams?.let { p ->
            if (locked) {
                p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            try { (guideWm ?: defaultWindowManager).updateViewLayout(guideView, p) } catch (_: Exception) {}
        }

        updateGuideVisuals()
        updateLockBtnState()

        if (showToast) {
            doVibrate(20)
            if (locked) {
                saveCurrentPositionsAndSettings(false)
                Toast.makeText(
                    this,
                    "🔒 位置を保存・固定しました (透過モード)\n目印の下のボタンを直接タップできます",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "✋ 移動モードにしました\n①と🎯をドラッグして配置後、指を離すと自動で固定・保存されます",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else if (locked) {
            saveCurrentPositionsAndSettings(false)
        }
    }

    private fun updateGuideVisuals() {
        val outerRing = guideOuterRing
        val apertureRing = guideApertureRing
        val badge = guideBadgeText

        if (isTargetsLocked) {
            // Locked & Pass-Through State (Emerald Cyan)
            outerRing?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#15059669"))
                setStroke(dpToPx(2f), Color.parseColor("#059669"))
            }
            apertureRing?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dpToPx(1.5f), Color.parseColor("#38BDF8"))
            }
            badge?.apply {
                text = "🔒透過"
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#065F46"))
                    cornerRadius = dpToPx(8f).toFloat()
                    setStroke(1, Color.parseColor("#34D399"))
                }
            }
        } else {
            // Move Mode (Bright Amber-Orange)
            outerRing?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#30EA580C"))
                setStroke(dpToPx(2.5f), Color.parseColor("#EA580C"))
            }
            apertureRing?.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dpToPx(1.5f), Color.parseColor("#FB923C"))
            }
            badge?.apply {
                text = "✋移動中"
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#C2410C"))
                    cornerRadius = dpToPx(8f).toFloat()
                    setStroke(1, Color.parseColor("#FDBA74"))
                }
            }
        }
    }

    private fun updateLockBtnState() {
        lockToggleBtn?.apply {
            if (isTargetsLocked) {
                text = "🔒固定(透過中)"
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#059669"))
                    cornerRadius = dpToPx(8f).toFloat()
                }
            } else {
                text = "✋移動中(押して固定)"
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#EA580C"))
                    cornerRadius = dpToPx(8f).toFloat()
                }
            }
        }
    }

    fun applyTargetPositionsToViews() {
        target1LayoutParams?.let { p ->
            p.x = target1X - targetRadiusPx
            p.y = target1Y - targetRadiusPx
            try { (target1Wm ?: defaultWindowManager).updateViewLayout(target1View, p) } catch (_: Exception) {}
        }
        guideLayoutParams?.let { p ->
            p.x = guideX - guideRadiusPx
            p.y = guideY - guideRadiusPx
            try { (guideWm ?: defaultWindowManager).updateViewLayout(guideView, p) } catch (_: Exception) {}
        }
    }

    fun saveCurrentPositionsAndSettings(showToast: Boolean = false) {
        if (target1X > 0 && target1Y > 0 && guideX > 0 && guideY > 0) {
            presetRepo.saveLastCoordinates(target1X, target1Y, guideX, guideY)
        }
        presetRepo.saveTargetTime(targetHour, targetMinute, targetSecond, targetMillisecond)
        hudLayoutParams?.let { hp ->
            presetRepo.saveHudPosition(hp.x, hp.y)
        }
        presetRepo.saveClockState(floatingClockX, floatingClockY, isFloatingClockVisible)

        currentPresetTitle?.let { title ->
            presetRepo.updatePresetCoordinatesByName(title, target1X, target1Y, guideX, guideY)
        }

        if (showToast) {
            doVibrate(25)
            Toast.makeText(
                this,
                "💾 位置と設定を保存しました！\n①:($target1X, $target1Y) 🎯:($guideX, $guideY)\n次回起動時もこの位置を引き継ぎます",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * Nudge coordinates by delta pixels
     */
    fun nudgeTarget1(dx: Int, dy: Int) {
        val params = target1LayoutParams ?: return
        params.x += dx; params.y += dy
        target1X = params.x + targetRadiusPx
        target1Y = params.y + targetRadiusPx
        try { (target1Wm ?: defaultWindowManager).updateViewLayout(target1View, params) } catch (_: Exception) {}
        saveCurrentPositionsAndSettings(false)
        doVibrate(15)
    }

    fun nudgeGuide(dx: Int, dy: Int) {
        val params = guideLayoutParams ?: return
        params.x += dx; params.y += dy
        guideX = params.x + guideRadiusPx
        guideY = params.y + guideRadiusPx
        try { (guideWm ?: defaultWindowManager).updateViewLayout(guideView, params) } catch (_: Exception) {}
        saveCurrentPositionsAndSettings(false)
        doVibrate(15)
    }

    /**
     * Standalone Floating Mini-Clock Pill:
     * High-visibility atomic clock pill with 2-digit milliseconds that user can drag anywhere freely!
     */
    private fun toggleFloatingClock(show: Boolean? = null) {
        val targetState = show ?: !isFloatingClockVisible
        if (targetState == isFloatingClockVisible) return
        isFloatingClockVisible = targetState

        if (isFloatingClockVisible) {
            createFloatingClockView()
            floatingClockBtn?.text = "⏱独立時計:ON"
            floatingClockBtn?.background = GradientDrawable().apply {
                setColor(Color.parseColor("#0284C7"))
                cornerRadius = dpToPx(8f).toFloat()
            }
            Toast.makeText(this, "⏱️ 独立フローティング時計を表示しました（画面上の好きな位置へドラッグできます）", Toast.LENGTH_SHORT).show()
        } else {
            removeFloatingClockView()
            floatingClockBtn?.text = "⏱独立時計"
            floatingClockBtn?.background = GradientDrawable().apply {
                setColor(Color.parseColor("#27272A"))
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#52525B"))
            }
            Toast.makeText(this, "⏱️ 独立時計を格納しました（上部HUDに常時表示中）", Toast.LENGTH_SHORT).show()
        }
        presetRepo.saveClockState(floatingClockX, floatingClockY, isFloatingClockVisible)
    }

    private fun createFloatingClockView() {
        if (floatingClockView != null) return
        val (wm, layoutFlag) = getBestWindowManager()
        floatingClockWm = wm

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = floatingClockX
            y = floatingClockY
        }
        floatingClockLayoutParams = params

        val ctx = getOverlayContext()
        val pill = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(10f), dpToPx(5f), dpToPx(8f), dpToPx(5f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE18181B"))
                cornerRadius = dpToPx(16f).toFloat()
                setStroke(dpToPx(1.5f), Color.parseColor("#38BDF8"))
            }
        }

        val clockTv = TextView(ctx).apply {
            text = "⏱️ 00:00:00.00"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 14f
            paint.isFakeBoldText = true
            typeface = android.graphics.Typeface.MONOSPACE
            setSingleLine(true)
            includeFontPadding = false
        }
        floatingClockText = clockTv
        pill.addView(clockTv)

        val closeBtn = TextView(ctx).apply {
            text = "✕"
            textSize = 11f
            setTextColor(Color.parseColor("#94A3B8"))
            setPadding(dpToPx(6f), dpToPx(2f), dpToPx(2f), dpToPx(2f))
            setOnClickListener { toggleFloatingClock(false) }
        }
        pill.addView(closeBtn)

        var initX = 0; var initY = 0; var touchX = 0f; var touchY = 0f
        pill.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x; initY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initX + (event.rawX - touchX).toInt()
                    params.y = initY + (event.rawY - touchY).toInt()
                    floatingClockX = params.x
                    floatingClockY = params.y
                    try { (floatingClockWm ?: defaultWindowManager).updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    presetRepo.saveClockState(floatingClockX, floatingClockY, isFloatingClockVisible)
                    true
                }
                else -> false
            }
        }
        floatingClockWm = addOverlayViewSafe(pill, params)
    }

    private fun removeFloatingClockView() {
        floatingClockView?.let { fcv ->
            try { (floatingClockWm ?: defaultWindowManager).removeView(fcv) } catch (_: Exception) {}
        }
        floatingClockView = null
        floatingClockText = null
    }

    /**
     * Floating HUD:
     * - Row 1: Status Pill (Preset Title + Target .50) + Close Button
     * - Row 2: Integrated Atomic Clock (NTP HH:mm:ss.SS) + Dynamic Countdown
     * - Row 3: Unified Lock/Move, Fast Test [ 1 ], Floating Clock Toggle, Settings, Arm button.
     */
    private fun createTopFloatingHud() {
        val (wm, layoutFlag) = getBestWindowManager()
        hudWm = wm

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            val savedHud = presetRepo.getHudPosition()
            if (savedHud != null) {
                x = savedHud.first
                y = savedHud.second
            } else {
                y = dpToPx(8f)
            }
        }
        hudLayoutParams = params

        val ctx = getOverlayContext()
        val hud = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            minimumWidth = dpToPx(340f)
            setPadding(dpToPx(10f), dpToPx(8f), dpToPx(10f), dpToPx(8f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F518181B"))
                cornerRadius = dpToPx(20f).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#3F3F46"))
            }
        }

        // ROW 1: STATUS PILL + CLOSE BUTTON
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(5f))
        }

        statusBadge = TextView(this).apply {
            text = formatStatusBadgeText()
            setTextColor(Color.WHITE)
            textSize = 10f
            paint.isFakeBoldText = true
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dpToPx(9f), dpToPx(3.5f), dpToPx(9f), dpToPx(3.5f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#27272A"))
                cornerRadius = dpToPx(10f).toFloat()
            }
        }
        row1.addView(statusBadge, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dpToPx(6f) })

        val closeBtn = Button(this).apply {
            text = "✕ 終了"
            textSize = 10f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#DC2626"))
                cornerRadius = dpToPx(10f).toFloat()
            }
            setPadding(dpToPx(9f), 0, dpToPx(9f), 0)
            setOnClickListener {
                Toast.makeText(this@FloatingOverlayService, "あたり！予約成功クリッカー を終了しました", Toast.LENGTH_SHORT).show()
                removeAllViewsAndStop()
            }
        }
        row1.addView(closeBtn, LinearLayout.LayoutParams(-2, dpToPx(24f)))
        hud.addView(row1)

        // ROW 2: INTEGRATED ATOMIC CLOCK BAR (2-digit milliseconds!)
        val clockBanner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(10f), dpToPx(6f), dpToPx(10f), dpToPx(6f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#18181B"))
                cornerRadius = dpToPx(12f).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#27272A"))
            }
        }

        val clockContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        hudAtomicClockText = TextView(this).apply {
            text = "⏱️ 00:00:00.00"
            setTextColor(Color.parseColor("#38BDF8")) // Neon Cyan
            textSize = 15.5f
            paint.isFakeBoldText = true
            typeface = android.graphics.Typeface.MONOSPACE
            includeFontPadding = false
        }
        clockContainer.addView(hudAtomicClockText)

        val syncHintTv = TextView(this).apply {
            text = "● 日本標準時 (NICT原子時計同期)"
            setTextColor(Color.parseColor("#34D399")) // Emerald
            textSize = 8.5f
            paint.isFakeBoldText = true
            includeFontPadding = false
        }
        clockContainer.addView(syncHintTv)
        clockBanner.addView(clockContainer, LinearLayout.LayoutParams(0, -2, 1f))

        countdownText = TextView(this).apply {
            text = "⏳ 残り 00:00.00"
            setTextColor(Color.parseColor("#FDE047")) // Bright Gold
            textSize = 12f
            paint.isFakeBoldText = true
            typeface = android.graphics.Typeface.MONOSPACE
            includeFontPadding = false
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        clockBanner.addView(countdownText, LinearLayout.LayoutParams(-2, -2))

        hud.addView(clockBanner, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpToPx(6f) })

        // ROW 3: SCROLLABLE CONTROL BUTTONS
        // Lock/Move + SavePos + NudgeSettings + Test[1] + Front + Floating Clock + Arm/Stop
        val row3Scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Unified Lock / Move Toggle Button
        lockToggleBtn = Button(this).apply {
            textSize = 9.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            setSingleLine(true); maxLines = 1
            setPadding(dpToPx(6f), 0, dpToPx(6f), 0)
            setOnClickListener {
                setTargetsLocked(!isTargetsLocked)
            }
        }
        updateLockBtnState()
        row3.addView(lockToggleBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)).apply { rightMargin = dpToPx(3f) })

        // Direct Save Positions Button (Prominent Emerald Green)
        val saveHudBtn = Button(this).apply {
            text = "💾位置保存"
            textSize = 9.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            setSingleLine(true); maxLines = 1
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#059669")) // Bright Emerald Green
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#34D399"))
            }
            setPadding(dpToPx(7f), 0, dpToPx(7f), 0)
            setOnClickListener {
                if (target1X > 0 && target1Y > 0 && guideX > 0 && guideY > 0) {
                    presetRepo.updateAllPresetsCoordinates(target1X, target1Y, guideX, guideY)
                }
                saveCurrentPositionsAndSettings(showToast = false)
                doVibrate(35)
                Toast.makeText(
                    this@FloatingOverlayService,
                    "💾 現在の位置を全プリセットに保存しました！\n①:($target1X, $target1Y)  🎯:($guideX, $guideY)\n次回起動時もこの位置が自動で維持されます",
                    Toast.LENGTH_LONG
                ).show()
                updateStatusBadge()
            }
        }
        row3.addView(saveHudBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)).apply { rightMargin = dpToPx(3f) })

        // Settings / Fine-Tuning Remote Button
        val presetBtn = Button(this).apply {
            text = "⚙微調整"
            textSize = 9.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            setSingleLine(true); maxLines = 1
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#38BDF8"))
            }
            setPadding(dpToPx(6f), 0, dpToPx(6f), 0)
            setOnClickListener { showFloatingQuickSettings() }
        }
        row3.addView(presetBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)).apply { rightMargin = dpToPx(3f) })

        // Test Click Button (Tests Target 1: Instant 25ms click)
        val testBtn = Button(this).apply {
            text = "▶①テスト"
            textSize = 9.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            setSingleLine(true); maxLines = 1
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#7C3AED"))
                cornerRadius = dpToPx(8f).toFloat()
            }
            setPadding(dpToPx(6f), 0, dpToPx(6f), 0)
            setOnClickListener { executeImmediateTestClick() }
        }
        row3.addView(testBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)).apply { rightMargin = dpToPx(3f) })

        // Bring to front button (pops target 1 and guide 2 right in front of Click Assistant)
        val frontBtn = Button(this).apply {
            text = "🔝最前面"
            textSize = 9.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            setSingleLine(true); maxLines = 1
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#5B21B6")) // Deep Royal Purple
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#C084FC"))
            }
            setPadding(dpToPx(6f), 0, dpToPx(6f), 0)
            setOnClickListener { bringAllToFront(showToast = true) }
        }
        row3.addView(frontBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)).apply { rightMargin = dpToPx(3f) })

        // Floating Standalone Clock Toggle Button
        floatingClockBtn = Button(this).apply {
            text = "⏱独立時計"
            textSize = 9.5f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            setSingleLine(true); maxLines = 1
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#27272A"))
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#52525B"))
            }
            setPadding(dpToPx(6f), 0, dpToPx(6f), 0)
            setOnClickListener { toggleFloatingClock() }
        }
        row3.addView(floatingClockBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)).apply { rightMargin = dpToPx(3f) })

        // Arm / Stop Button
        armToggleBtn = Button(this).apply {
            text = if (isArmed) "■ 停止" else "● 予約"
            textSize = 10f
            paint.isFakeBoldText = true
            setTextColor(Color.WHITE)
            minWidth = dpToPx(50f); minimumWidth = dpToPx(50f)
            includeFontPadding = false
            setSingleLine(true); maxLines = 1
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(if (isArmed) Color.parseColor("#DC2626") else Color.parseColor("#059669"))
                cornerRadius = dpToPx(8f).toFloat()
            }
            setPadding(dpToPx(6f), 0, dpToPx(6f), 0)
            setOnClickListener { toggleArm() }
        }
        row3.addView(armToggleBtn, LinearLayout.LayoutParams(-2, dpToPx(27f)))
        row3Scroll.addView(row3)
        hud.addView(row3Scroll)

        var hudInitX = 0; var hudInitY = 0; var hudTouchX = 0f; var hudTouchY = 0f
        row1.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    hudInitX = params.x; hudInitY = params.y
                    hudTouchX = event.rawX; hudTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = hudInitX + (event.rawX - hudTouchX).toInt()
                    params.y = hudInitY + (event.rawY - hudTouchY).toInt()
                    try { (hudWm ?: defaultWindowManager).updateViewLayout(hud, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    presetRepo.saveHudPosition(params.x, params.y)
                    true
                }
                else -> false
            }
        }
        hudView = hud
        hudWm = addOverlayViewSafe(hud, params)
    }

    /**
     * Fast Test Click for Target 1:
     * - Guarantees target1 has FLAG_NOT_TOUCHABLE so it NEVER intercepts the tap!
     * - Dispatches hardware-level tap at (target1X, target1Y) into Click Assistant's play button.
     */
    private fun executeImmediateTestClick() {
        val service = AutoClickAccessibilityService.instance
        if (service == null) {
            Toast.makeText(
                this,
                "⚠️ ユーザー補助が無効です。端末の「設定」>「ユーザー補助」で あたり！予約成功クリッカー をONにしてください",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        doVibrate(15)

        // Visual flash feedback on Target 1
        target1View?.animate()?.scaleX(1.25f)?.scaleY(1.25f)?.setDuration(70)?.withEndAction {
            target1View?.animate()?.scaleX(1.0f)?.scaleY(1.0f)?.setDuration(100)?.start()
        }?.start()

        // ENSURE target1 has FLAG_NOT_TOUCHABLE before tap injection so it CANNOT intercept!
        target1LayoutParams?.let { p ->
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { (target1Wm ?: defaultWindowManager).updateViewLayout(target1View, p) } catch (_: Exception) {}
        }

        service.performTap(target1X, target1Y, tapDurationMs) { success, message ->
            // If currently in move mode, restore touchability
            if (!isTargetsLocked) {
                target1LayoutParams?.let { p ->
                    p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                    try { (target1Wm ?: defaultWindowManager).updateViewLayout(target1View, p) } catch (_: Exception) {}
                }
            }

            if (success) {
                doVibrate(20)
                Toast.makeText(this, "✓ ①位置 ($target1X, $target1Y) をタップしました！", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun doVibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    private fun toggleArm() {
        isArmed = !isArmed
        isExecuted = false
        executedTimeStr = null
        resetBuzzFlags()

        updateArmButtonState()
        updateStatusBadge()

        if (isArmed) {
            // When armed for auto-click, ensure targets are locked so touches pass straight through!
            setTargetsLocked(true, showToast = false)
            promoteToAccessibilityOverlay()
            bringAllToFront(showToast = false)
            Toast.makeText(
                this,
                "✓ ${formatTargetTimeStr()} に待機を開始しました！\n時刻に①が自動タップされ、画面遷移後に🎯目印を手動タップしてください",
                Toast.LENGTH_LONG
            ).show()
        } else {
            Toast.makeText(this, "待機を停止しました", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateArmButtonState() {
        armToggleBtn?.text = if (isArmed) "■ 停止" else "● 予約"
        armToggleBtn?.background = GradientDrawable().apply {
            setColor(if (isArmed) Color.parseColor("#DC2626") else Color.parseColor("#059669"))
            cornerRadius = dpToPx(8f).toFloat()
        }
    }

    private fun updateStatusBadge() {
        statusBadge?.text = formatStatusBadgeText()
    }

    private fun formatStatusBadgeText(): String {
        val ms2 = targetMillisecond / 10
        val a11yOk = AutoClickAccessibilityService.isRunning()
        val a11yTag = if (a11yOk) "🟢" else "🔴補助OFF "
        return if (isArmed) {
            "[v1.2.6] ${a11yTag}予約中: $currentPresetTitle (${String.format("%02d:%02d:%02d.%02d", targetHour, targetMinute, targetSecond, ms2)})"
        } else if (isExecuted) {
            "[v1.2.6] ${a11yTag}①実行完了: " + (executedTimeStr ?: "") + " → 🎯目印へ！"
        } else {
            "[v1.2.6] ${a11yTag}停止中: ${String.format("%02d:%02d:%02d.%02d", targetHour, targetMinute, targetSecond, ms2)} [①($target1X,$target1Y) 🎯($guideX,$guideY)]"
        }
    }

    private fun formatTargetTimeStr(): String {
        return String.format("%02d:%02d:%02d.%02d", targetHour, targetMinute, targetSecond, targetMillisecond / 10)
    }

    private fun startCountdownTicker() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive) {
                val nowNtp = NtpEngine.getAccurateTimeMs()
                val targetMs = calculateNextTargetEpochMs(nowNtp)
                val diffMs = targetMs - nowNtp

                // Update Atomic Clock (Current NTP Time with 2-digit milliseconds)
                val cal = Calendar.getInstance().apply { timeInMillis = nowNtp }
                val h = cal.get(Calendar.HOUR_OF_DAY)
                val m = cal.get(Calendar.MINUTE)
                val s = cal.get(Calendar.SECOND)
                val ms2 = cal.get(Calendar.MILLISECOND) / 10 // 0..99 (Centiseconds)
                val clockStr = String.format("⏱️ %02d:%02d:%02d.%02d", h, m, s, ms2)

                hudAtomicClockText?.text = clockStr
                floatingClockText?.text = clockStr

                if (isArmed) {
                    if (diffMs in 2800..3200 && !buzz3sDone) {
                        buzz3sDone = true
                        doVibrate(20)
                    }
                    if (diffMs in 1800..2200 && !buzz2sDone) {
                        buzz2sDone = true
                        doVibrate(20)
                    }
                    if (diffMs in 800..1200 && !buzz1sDone) {
                        buzz1sDone = true
                        doVibrate(20)
                    }

                    if (diffMs <= 15) {
                        triggerArmedExecution(nowNtp)
                    } else {
                        updateCountdownDisplay(diffMs)
                    }
                } else {
                    updateCountdownDisplay(null)
                }

                // Smooth 20ms refresh for 2-digit milliseconds; 5ms when approaching target
                val sleepTime = if (isArmed && diffMs < 3000) 5L else 20L
                delay(sleepTime)
            }
        }
    }

    private fun calculateNextTargetEpochMs(nowEpochMs: Long): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowEpochMs
            set(Calendar.HOUR_OF_DAY, targetHour)
            set(Calendar.MINUTE, targetMinute)
            set(Calendar.SECOND, targetSecond)
            set(Calendar.MILLISECOND, targetMillisecond)
        }
        if (cal.timeInMillis <= nowEpochMs) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    private fun updateCountdownDisplay(diffMs: Long?) {
        if (diffMs == null) {
            countdownText?.text = if (isExecuted) "✓ 完了" else "⏸️ 停止中"
            return
        }
        val totalSec = diffMs / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        val centis = (diffMs % 1000) / 10

        if (diffMs < 10000) {
            // Under 10 seconds: High urgency dynamic focus
            countdownText?.text = String.format("⚡ %d.%02d秒!", totalSec, centis)
        } else {
            countdownText?.text = String.format("⏳ 残り %02d:%02d.%02d", m, s, centis)
        }
    }

    /**
     * Executes Auto-Tap on Target 1 at exact scheduled time.
     */
    private fun triggerArmedExecution(firedEpochMs: Long) {
        isArmed = false
        isExecuted = true
        resetBuzzFlags()

        val cal = Calendar.getInstance().apply { timeInMillis = firedEpochMs }
        val ms2 = cal.get(Calendar.MILLISECOND) / 10
        executedTimeStr = String.format("%02d:%02d:%02d.%02d",
            cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND), ms2)

        updateArmButtonState()
        updateStatusBadge()

        // 1. Ensure FLAG_NOT_TOUCHABLE is set so it doesn't intercept
        target1LayoutParams?.let { p ->
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { (target1Wm ?: defaultWindowManager).updateViewLayout(target1View, p) } catch (_: Exception) {}
        }

        // Visual flash feedback on Target 1
        target1View?.animate()?.scaleX(1.25f)?.scaleY(1.25f)?.setDuration(70)?.withEndAction {
            target1View?.animate()?.scaleX(1.0f)?.scaleY(1.0f)?.setDuration(100)?.start()
        }?.start()

        // 2. Auto-Click Target 1
        val a11y = AutoClickAccessibilityService.instance
        if (a11y != null) {
            a11y.performTap(target1X, target1Y, tapDurationMs) { success, msg ->
                if (success) {
                    doVibrate(60)
                    countdownText?.text = "🎯目印へGO！"
                    Toast.makeText(
                        this@FloatingOverlayService,
                        "🎉 ①を自動タップしました！($executedTimeStr)\n遷移後、🎯目印を目がけて手動タップしてください！",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    doVibrate(30)
                    countdownText?.text = "⚠️タップ失敗"
                    Toast.makeText(
                        this@FloatingOverlayService,
                        "⚠️ 自動タップがキャンセルされました: $msg",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        } else {
            // Accessibility service is disabled or disconnected
            doVibrate(30)
            serviceScope.launch {
                kotlinx.coroutines.delay(100)
                doVibrate(30)
            }
            countdownText?.text = "⚠️補助OFF"
            Toast.makeText(
                this,
                "⚠️ ユーザー補助がOFFのため自動タップできませんでした！\n端末の「設定」>「ユーザー補助」で「あたり！予約成功クリッカー」をONにしてください",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun closeSettingsOverlay() {
        settingsOverlayView?.let { sv ->
            try { (settingsWm ?: defaultWindowManager).removeView(sv) } catch (_: Exception) {}
        }
        settingsOverlayView = null
        bringAllToFront(showToast = false)
    }

    /**
     * Floating Quick Settings Window:
     */
    private fun showFloatingQuickSettings() {
        if (settingsOverlayView != null) {
            closeSettingsOverlay()
            return
        }

        val (wm, layoutFlag) = getBestWindowManager()
        settingsWm = wm

        val ctx = getOverlayContext()
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(14f), dpToPx(12f), dpToPx(14f), dpToPx(12f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E60F172A")) // Translucent slate glass (90% opacity: see through to underlying marks)
                cornerRadius = dpToPx(16f).toFloat()
                setStroke(dpToPx(1.5f), Color.parseColor("#38BDF8"))
            }
        }

        val scroll = ScrollView(ctx).apply {
            isFillViewport = true
            addView(card)
        }

        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val dialogW = dpToPx(320f).coerceAtMost((screenW * 0.94f).toInt())
        val dialogH = dpToPx(380f).coerceAtMost((screenH * 0.48f).toInt())

        val params = WindowManager.LayoutParams(
            dialogW,
            dialogH,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - dialogW) / 2
            y = dpToPx(65f)
        }

        // Header: Drag handle + Title + Jump (⬇下/⬆上) + Close
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(8f))
        }
        val title = TextView(this).apply {
            text = "⚙️ 微調整リモコン"
            textSize = 13f
            setTextColor(Color.WHITE)
            paint.isFakeBoldText = true
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

        var isAtBottom = false
        val jumpBtn = Button(this).apply {
            text = "⬇下へ退避"
            textSize = 10f
            paint.isFakeBoldText = true
            setTextColor(Color.parseColor("#38BDF8"))
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#0284C7"))
            }
            setPadding(dpToPx(8f), 0, dpToPx(8f), 0)
            setOnClickListener {
                isAtBottom = !isAtBottom
                if (isAtBottom) {
                    params.y = (screenH - dialogH - dpToPx(30f)).coerceAtLeast(dpToPx(80f))
                    text = "⬆上へ戻す"
                    Toast.makeText(this@FloatingOverlayService, "⬇ ウィンドウを下部に退避しました（上部のマークが見やすくなります）", Toast.LENGTH_SHORT).show()
                } else {
                    params.y = dpToPx(65f)
                    text = "⬇下へ退避"
                    Toast.makeText(this@FloatingOverlayService, "⬆ ウィンドウを上部に戻しました", Toast.LENGTH_SHORT).show()
                }
                try { (settingsWm ?: defaultWindowManager).updateViewLayout(scroll, params) } catch (_: Exception) {}
            }
        }
        header.addView(jumpBtn, LinearLayout.LayoutParams(-2, dpToPx(28f)).apply { rightMargin = dpToPx(6f) })

        val closeBtn = Button(this).apply {
            text = "✕"
            textSize = 13f
            setTextColor(Color.WHITE)
            minWidth = dpToPx(28f); minimumWidth = dpToPx(28f); includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#334155"))
                cornerRadius = dpToPx(14f).toFloat()
            }
            setOnClickListener { closeSettingsOverlay() }
        }
        header.addView(closeBtn, LinearLayout.LayoutParams(dpToPx(28f), dpToPx(28f)))

        // Header touch listener for free window dragging anywhere on screen
        var dragInitX = 0; var dragInitY = 0; var dragTouchX = 0f; var dragTouchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragInitX = params.x; dragInitY = params.y
                    dragTouchX = event.rawX; dragTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = dragInitX + (event.rawX - dragTouchX).toInt()
                    params.y = dragInitY + (event.rawY - dragTouchY).toInt()
                    try { (settingsWm ?: defaultWindowManager).updateViewLayout(scroll, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        card.addView(header)

        var stepPx = 2

        // Section 1: Target 1 Position (Auto Tap)
        val target1Label = TextView(this).apply {
            text = "① 自動タップ位置: (X=$target1X, Y=$target1Y)"
            setTextColor(Color.parseColor("#C084FC"))
            textSize = 11f
            paint.isFakeBoldText = true
            setPadding(0, dpToPx(2f), 0, dpToPx(4f))
        }
        card.addView(target1Label)

        val t1Row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dpToPx(8f))
        }
        fun makeT1Btn(label: String, dx: Int, dy: Int): Button {
            return Button(this).apply {
                text = label
                textSize = 10.5f; paint.isFakeBoldText = true; setTextColor(Color.WHITE)
                minWidth = 0; minimumWidth = 0; includeFontPadding = false
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1E293B"))
                    cornerRadius = dpToPx(6f).toFloat()
                    setStroke(1, Color.parseColor("#7C3AED"))
                }
                setOnClickListener {
                    nudgeTarget1(dx * stepPx, dy * stepPx)
                    target1Label.text = "① 自動タップ位置: (X=$target1X, Y=$target1Y)"
                    updateStatusBadge()
                }
            }
        }
        t1Row.addView(makeT1Btn("⬆ 上", 0, -1), LinearLayout.LayoutParams(0, dpToPx(30f), 1f).apply { rightMargin = dpToPx(3f) })
        t1Row.addView(makeT1Btn("⬇ 下", 0, 1), LinearLayout.LayoutParams(0, dpToPx(30f), 1f).apply { rightMargin = dpToPx(3f) })
        t1Row.addView(makeT1Btn("⬅ 左", -1, 0), LinearLayout.LayoutParams(0, dpToPx(30f), 1f).apply { rightMargin = dpToPx(3f) })
        t1Row.addView(makeT1Btn("➡ 右", 1, 0), LinearLayout.LayoutParams(0, dpToPx(30f), 1f))
        card.addView(t1Row)

        // Section 2: Target 2 Position (🎯 手動目印ガイド)
        val guideLabel = TextView(this).apply {
            text = "🎯 手動目印位置: (X=$guideX, Y=$guideY)"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 11f
            paint.isFakeBoldText = true
            setPadding(0, dpToPx(2f), 0, dpToPx(4f))
        }
        card.addView(guideLabel)

        val gRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dpToPx(8f))
        }
        fun makeGBtn(label: String, dx: Int, dy: Int): Button {
            return Button(this).apply {
                text = label
                textSize = 10.5f; paint.isFakeBoldText = true; setTextColor(Color.WHITE)
                minWidth = 0; minimumWidth = 0; includeFontPadding = false
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1E293B"))
                    cornerRadius = dpToPx(6f).toFloat()
                    setStroke(1, Color.parseColor("#0284C7"))
                }
                setOnClickListener {
                    nudgeGuide(dx * stepPx, dy * stepPx)
                    guideLabel.text = "🎯 手動目印位置: (X=$guideX, Y=$guideY)"
                    updateStatusBadge()
                }
            }
        }
        gRow.addView(makeGBtn("⬆ 上", 0, -1), LinearLayout.LayoutParams(0, dpToPx(30f), 1f).apply { rightMargin = dpToPx(3f) })
        gRow.addView(makeGBtn("⬇ 下", 0, 1), LinearLayout.LayoutParams(0, dpToPx(30f), 1f).apply { rightMargin = dpToPx(3f) })
        gRow.addView(makeGBtn("⬅ 左", -1, 0), LinearLayout.LayoutParams(0, dpToPx(30f), 1f).apply { rightMargin = dpToPx(3f) })
        gRow.addView(makeGBtn("➡ 右", 1, 0), LinearLayout.LayoutParams(0, dpToPx(30f), 1f))
        card.addView(gRow)

        // Save Current Coordinates & Settings Button (PROMINENT BRIGHT EMERALD GREEN)
        val savePosBtn = Button(this).apply {
            text = "💾 現在の①&🎯位置を全プリセットに保存"
            textSize = 12f; paint.isFakeBoldText = true; setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#059669"))
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(dpToPx(1f), Color.parseColor("#34D399"))
            }
            setOnClickListener {
                if (target1X > 0 && target1Y > 0 && guideX > 0 && guideY > 0) {
                    presetRepo.updateAllPresetsCoordinates(target1X, target1Y, guideX, guideY)
                }
                saveCurrentPositionsAndSettings(showToast = false)
                doVibrate(35)
                Toast.makeText(
                    this@FloatingOverlayService,
                    "💾 現在の位置を全プリセットに保存しました！\n①:($target1X, $target1Y)  🎯:($guideX, $guideY)\n次回起動時もこの位置が自動で維持されます",
                    Toast.LENGTH_LONG
                ).show()
                updateStatusBadge()
            }
        }
        card.addView(savePosBtn, LinearLayout.LayoutParams(-1, dpToPx(38f)).apply { bottomMargin = dpToPx(8f) })

        // Section 3: Floating Clock Toggle in Settings
        val clockOptRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(8f))
        }
        clockOptRow.addView(TextView(this).apply {
            text = "⏱️ 独立フローティング時計:"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
        }, LinearLayout.LayoutParams(0, -2, 1f))

        val clockToggleSettingsBtn = Button(this).apply {
            text = if (isFloatingClockVisible) "表示中 (OFFにする)" else "非表示 (画面に出す)"
            textSize = 10.5f; paint.isFakeBoldText = true
            setTextColor(if (isFloatingClockVisible) Color.parseColor("#38BDF8") else Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#334155"))
                cornerRadius = dpToPx(8f).toFloat()
            }
            setPadding(dpToPx(10f), 0, dpToPx(10f), 0)
            setOnClickListener {
                toggleFloatingClock()
                text = if (isFloatingClockVisible) "表示中 (OFFにする)" else "非表示 (画面に出す)"
                setTextColor(if (isFloatingClockVisible) Color.parseColor("#38BDF8") else Color.WHITE)
            }
        }
        clockOptRow.addView(clockToggleSettingsBtn, LinearLayout.LayoutParams(-2, dpToPx(28f)))
        card.addView(clockOptRow)

        // Step toggle button
        val stepRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(8f))
        }
        stepRow.addView(TextView(this).apply {
            text = "微調整ステップ:"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
        }, LinearLayout.LayoutParams(0, -2, 1f))

        val stepToggleBtn = Button(this).apply {
            text = "${stepPx}px (タップで切替)"
            textSize = 10.5f; paint.isFakeBoldText = true
            setTextColor(Color.parseColor("#FDE047"))
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#334155"))
                cornerRadius = dpToPx(8f).toFloat()
            }
            setPadding(dpToPx(10f), 0, dpToPx(10f), 0)
            setOnClickListener {
                stepPx = if (stepPx == 2) 10 else 2
                text = "${stepPx}px (タップで切替)"
                doVibrate(15)
            }
        }
        stepRow.addView(stepToggleBtn, LinearLayout.LayoutParams(-2, dpToPx(28f)))
        card.addView(stepRow)

        // Section 4: Current Target Time & Saved Presets
        val curTimeBox = TextView(this).apply {
            text = "現在予定: ${formatTargetTimeStr()}"
            textSize = 12.5f
            setTextColor(Color.parseColor("#FDE047"))
            paint.isFakeBoldText = true
            gravity = Gravity.CENTER
            setPadding(dpToPx(8f), dpToPx(5f), dpToPx(8f), dpToPx(5f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dpToPx(8f).toFloat()
                setStroke(1, Color.parseColor("#475569"))
            }
        }
        card.addView(curTimeBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dpToPx(6f) })

        val savedPresets = presetRepo.getAllPresets()
        if (savedPresets.isNotEmpty()) {
            val presetScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
            }
            val presetRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, dpToPx(6f))
            }

            savedPresets.forEach { p ->
                val isCur = p.name == currentPresetTitle
                val pBtn = Button(this).apply {
                    text = "${p.name}\n${String.format("%02d:%02d", p.targetHour, p.targetMinute)}"
                    textSize = 10f
                    paint.isFakeBoldText = true
                    setTextColor(if (isCur) Color.parseColor("#FDE047") else Color.WHITE)
                    minWidth = dpToPx(68f); minimumWidth = dpToPx(68f)
                    includeFontPadding = false; gravity = Gravity.CENTER
                    background = GradientDrawable().apply {
                        setColor(if (isCur) Color.parseColor("#3730A3") else Color.parseColor("#1E293B"))
                        cornerRadius = dpToPx(8f).toFloat()
                        setStroke(dpToPx(1f), if (isCur) Color.parseColor("#818CF8") else Color.parseColor("#334155"))
                    }
                    setPadding(dpToPx(6f), dpToPx(4f), dpToPx(6f), dpToPx(4f))
                    setOnClickListener {
                        doVibrate(20)
                        targetHour = p.targetHour
                        targetMinute = p.targetMinute
                        targetSecond = p.targetSecond
                        targetMillisecond = p.targetMillisecond
                        currentPresetTitle = p.name
                        curTimeBox.text = "現在予定: ${formatTargetTimeStr()}"
                        updateStatusBadge()
                        saveCurrentPositionsAndSettings(false)
                        Toast.makeText(
                            this@FloatingOverlayService,
                            "✓ 「${p.name}」(${formatTargetTimeStr()}) に切替ました\n（ターゲットと目印の位置は現在位置を維持）",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
                presetRow.addView(pBtn, LinearLayout.LayoutParams(-2, dpToPx(36f)).apply { rightMargin = dpToPx(5f) })
            }
            presetScroll.addView(presetRow)
            card.addView(presetScroll)
        }

        // Section 5: Open MainActivity Button
        val openAppBtn = Button(this).apply {
            text = "📱 メインアプリを開く（プリセット編集・登録）"
            textSize = 11f; paint.isFakeBoldText = true; setTextColor(Color.WHITE)
            minWidth = 0; minimumWidth = 0; includeFontPadding = false
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#6366F1"))
                cornerRadius = dpToPx(8f).toFloat()
            }
            setOnClickListener {
                closeSettingsOverlay()
                try {
                    val intent = Intent(this@FloatingOverlayService, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@FloatingOverlayService, "アプリを開けませんでした", Toast.LENGTH_SHORT).show()
                }
            }
        }
        card.addView(openAppBtn, LinearLayout.LayoutParams(-1, dpToPx(34f)))

        settingsOverlayView = scroll
        settingsWm = addOverlayViewSafe(scroll, params)
    }

    fun removeAllViews() {
        hudView?.let { hv ->
            try { (hudWm ?: defaultWindowManager).removeViewImmediate(hv) } catch (_: Exception) {}
            try { defaultWindowManager.removeViewImmediate(hv) } catch (_: Exception) {}
        }
        hudView = null

        target1View?.let { tv ->
            try { (target1Wm ?: defaultWindowManager).removeViewImmediate(tv) } catch (_: Exception) {}
            try { defaultWindowManager.removeViewImmediate(tv) } catch (_: Exception) {}
        }
        target1View = null

        guideView?.let { gv ->
            try { (guideWm ?: defaultWindowManager).removeViewImmediate(gv) } catch (_: Exception) {}
            try { defaultWindowManager.removeViewImmediate(gv) } catch (_: Exception) {}
        }
        guideView = null

        removeFloatingClockView()
        closeSettingsOverlay()
    }

    fun removeAllViewsAndStop() {
        try {
            saveCurrentPositionsAndSettings(false)
        } catch (_: Exception) {}

        serviceScope.cancel()
        timerJob?.cancel()

        removeAllViews()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (_: Exception) {}

        instance = null
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllViewsAndStop()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
