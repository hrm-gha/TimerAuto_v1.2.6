package com.autoclicker.timer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.Log

class AutoClickAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoClickAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    private var a11yWindowManager: android.view.WindowManager? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        a11yWindowManager = getSystemService(android.content.Context.WINDOW_SERVICE) as? android.view.WindowManager
        Log.d("AutoClickService", "Accessibility Service Connected")
        try {
            FloatingOverlayService.instance?.promoteToAccessibilityOverlay()
        } catch (e: Exception) {
            Log.e("AutoClickService", "Failed to promote overlay on connect", e)
        }
    }

    fun getAccessibilityWindowManager(): android.view.WindowManager? {
        if (a11yWindowManager == null) {
            a11yWindowManager = getSystemService(android.content.Context.WINDOW_SERVICE) as? android.view.WindowManager
        }
        return a11yWindowManager
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        // Pure gesture engine: no event interception
    }

    override fun onInterrupt() {
        Log.d("AutoClickService", "Accessibility Service Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /**
     * Pure Physical Coordinate Tap (Identical to Click Assistant):
     * Directly injects a hardware touch event at absolute screen coordinates (x, y).
     * Single point Path with moveTo(x, y) - NO lineTo so browser interprets it as pure click, not a swipe/drag!
     */
    fun performTap(x: Int, y: Int, durationMs: Long = 40L, onResult: ((Boolean, String) -> Unit)? = null) {
        val path = Path().apply {
            moveTo(x.toFloat(), y.toFloat())
            // Single point only: NO lineTo to prevent browser touchmove/scroll cancellation!
        }

        val safeDuration = durationMs.coerceIn(35L, 60L)
        val stroke = GestureDescription.StrokeDescription(path, 0L, safeDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val mainHandler = Handler(Looper.getMainLooper())

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d("AutoClickService", "Tap completed at ($x, $y)")
                mainHandler.post {
                    onResult?.invoke(true, "✓ ターゲット [ 1 ] の位置 ($x, $y) をタップしました")
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                Log.w("AutoClickService", "Tap cancelled at ($x, $y) - auto retrying once...")
                mainHandler.postDelayed({
                    val retryStroke = GestureDescription.StrokeDescription(path, 0L, safeDuration)
                    val retryGesture = GestureDescription.Builder().addStroke(retryStroke).build()
                    val retryDispatched = dispatchGesture(retryGesture, object : GestureResultCallback() {
                        override fun onCompleted(desc: GestureDescription?) {
                            mainHandler.post {
                                onResult?.invoke(true, "✓ リトライで ($x, $y) をタップしました")
                            }
                        }
                        override fun onCancelled(desc: GestureDescription?) {
                            mainHandler.post {
                                onResult?.invoke(false, "⚠️ タップがキャンセルされました (画面に触れていないか確認してください)")
                            }
                        }
                    }, null)
                    if (!retryDispatched) {
                        mainHandler.post {
                            onResult?.invoke(false, "⚠️ タップの送信に失敗しました")
                        }
                    }
                }, 40L)
            }
        }, null)

        if (!dispatched) {
            Log.e("AutoClickService", "Failed to dispatch gesture at ($x, $y)")
            mainHandler.post {
                onResult?.invoke(false, "⚠️ タップの送信に失敗しました (ユーザー補助の状態を確認してください)")
            }
        }
    }
}
