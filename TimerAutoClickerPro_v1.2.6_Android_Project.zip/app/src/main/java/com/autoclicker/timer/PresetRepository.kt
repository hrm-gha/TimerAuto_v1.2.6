package com.autoclicker.timer

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class TapPreset(
    val id: String = java.util.UUID.randomUUID().toString(),
    var name: String,
    var targetHour: Int,
    var targetMinute: Int,
    var targetSecond: Int = 59,
    var targetMillisecond: Int = 500,
    var targetX: Int = 540,
    var targetY: Int = 700,
    var guideX: Int = 540,
    var guideY: Int = 1150,
    var manualOffsetMs: Int = 0
)

data class SavedCoordinates(
    val target1X: Int,
    val target1Y: Int,
    val guideX: Int,
    val guideY: Int
)

class PresetRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("auto_click_presets_v2", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getAllPresets(): List<TapPreset> {
        val json = prefs.getString("presets_list", null) ?: return defaultPresets().also { saveAll(it) }
        return try {
            val type = object : TypeToken<List<TapPreset>>() {}.type
            val list: List<TapPreset>? = gson.fromJson(json, type)
            if (list.isNullOrEmpty()) {
                defaultPresets().also { saveAll(it) }
            } else {
                // Ensure all fields have valid non-zero values
                list.forEach { p ->
                    if (p.targetX <= 0) p.targetX = 540
                    if (p.targetY <= 0) p.targetY = 700
                    if (p.guideX <= 0) p.guideX = 540
                    if (p.guideY <= 0) p.guideY = 1150
                }
                list
            }
        } catch (e: Exception) {
            defaultPresets().also { saveAll(it) }
        }
    }

    fun getAllPresetsJson(): String {
        return gson.toJson(getAllPresets())
    }

    private fun saveAll(list: List<TapPreset>) {
        prefs.edit().putString("presets_list", gson.toJson(list)).apply()
    }

    fun getLastSelectedPresetId(): String? {
        return prefs.getString("last_selected_preset_id", null)
    }

    fun setLastSelectedPresetId(id: String) {
        prefs.edit().putString("last_selected_preset_id", id).apply()
    }

    /**
     * Save global last-used coordinates (Target 1 & Guide 2)
     * Uses .commit() for immediate persistent synchronous disk write!
     */
    fun saveLastCoordinates(target1X: Int, target1Y: Int, guideX: Int, guideY: Int) {
        if (target1X <= 0 || target1Y <= 0 || guideX <= 0 || guideY <= 0) return
        prefs.edit()
            .putInt("last_target1_x", target1X)
            .putInt("last_target1_y", target1Y)
            .putInt("last_guide_x", guideX)
            .putInt("last_guide_y", guideY)
            .commit()
    }

    fun getLastCoordinates(): SavedCoordinates? {
        if (!prefs.contains("last_target1_x") || !prefs.contains("last_guide_x")) {
            return null
        }
        val t1X = prefs.getInt("last_target1_x", 0)
        val t1Y = prefs.getInt("last_target1_y", 0)
        val gX = prefs.getInt("last_guide_x", 0)
        val gY = prefs.getInt("last_guide_y", 0)
        if (t1X <= 0 || t1Y <= 0 || gX <= 0 || gY <= 0) return null
        return SavedCoordinates(t1X, t1Y, gX, gY)
    }

    fun saveHudPosition(x: Int, y: Int) {
        prefs.edit()
            .putInt("last_hud_x", x)
            .putInt("last_hud_y", y)
            .apply()
    }

    fun getHudPosition(): Pair<Int, Int>? {
        if (!prefs.contains("last_hud_x")) return null
        return Pair(prefs.getInt("last_hud_x", 0), prefs.getInt("last_hud_y", 0))
    }

    fun saveClockState(x: Int, y: Int, visible: Boolean) {
        prefs.edit()
            .putInt("last_clock_x", x)
            .putInt("last_clock_y", y)
            .putBoolean("last_clock_visible", visible)
            .apply()
    }

    fun getClockState(): Triple<Int, Int, Boolean>? {
        if (!prefs.contains("last_clock_x")) return null
        return Triple(
            prefs.getInt("last_clock_x", 40),
            prefs.getInt("last_clock_y", 250),
            prefs.getBoolean("last_clock_visible", false)
        )
    }

    fun saveTargetTime(hour: Int, minute: Int, second: Int, millisecond: Int) {
        prefs.edit()
            .putInt("last_target_hour", hour)
            .putInt("last_target_minute", minute)
            .putInt("last_target_second", second)
            .putInt("last_target_millisecond", millisecond)
            .apply()
    }

    fun getLastTargetTime(): IntArray? {
        if (!prefs.contains("last_target_hour")) return null
        return intArrayOf(
            prefs.getInt("last_target_hour", 21),
            prefs.getInt("last_target_minute", 0),
            prefs.getInt("last_target_second", 59),
            prefs.getInt("last_target_millisecond", 500)
        )
    }

    fun updatePresetCoordinates(id: String, target1X: Int, target1Y: Int, guideX: Int, guideY: Int): Boolean {
        val current = getAllPresets().toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index >= 0) {
            val existing = current[index]
            existing.targetX = target1X
            existing.targetY = target1Y
            existing.guideX = guideX
            existing.guideY = guideY
            saveAll(current)
            saveLastCoordinates(target1X, target1Y, guideX, guideY)
            return true
        }
        return false
    }

    fun updatePresetCoordinatesByName(name: String, target1X: Int, target1Y: Int, guideX: Int, guideY: Int): Boolean {
        val current = getAllPresets().toMutableList()
        val index = current.indexOfFirst { it.name == name }
        if (index >= 0) {
            val existing = current[index]
            existing.targetX = target1X
            existing.targetY = target1Y
            existing.guideX = guideX
            existing.guideY = guideY
            saveAll(current)
            saveLastCoordinates(target1X, target1Y, guideX, guideY)
            return true
        }
        return false
    }

    fun updateAllPresetsCoordinates(target1X: Int, target1Y: Int, guideX: Int, guideY: Int) {
        if (target1X <= 0 || target1Y <= 0 || guideX <= 0 || guideY <= 0) return
        val current = getAllPresets().toMutableList()
        current.forEach { p ->
            p.targetX = target1X
            p.targetY = target1Y
            p.guideX = guideX
            p.guideY = guideY
        }
        saveAll(current)
        saveLastCoordinates(target1X, target1Y, guideX, guideY)
    }

    fun saveOrUpdatePreset(
        id: String?,
        name: String,
        hour: Int,
        minute: Int,
        second: Int = 59,
        millisecond: Int = 500,
        targetX: Int = -1,
        targetY: Int = -1,
        guideX: Int = -1,
        guideY: Int = -1
    ): TapPreset {
        val current = getAllPresets().toMutableList()
        val cleanId = if (id.isNullOrBlank() || id == "null" || id == "undefined") null else id
        val existingIndex = if (cleanId != null) current.indexOfFirst { it.id == cleanId } else -1

        val lastCoords = getLastCoordinates()

        val preset = if (existingIndex >= 0) {
            val existing = current[existingIndex]
            existing.copy(
                name = name.trim().ifEmpty { "プリセット" },
                targetHour = hour.coerceIn(0, 23),
                targetMinute = minute.coerceIn(0, 59),
                targetSecond = second.coerceIn(0, 59),
                targetMillisecond = millisecond.coerceIn(0, 999),
                targetX = if (targetX > 0) targetX else existing.targetX,
                targetY = if (targetY > 0) targetY else existing.targetY,
                guideX = if (guideX > 0) guideX else existing.guideX,
                guideY = if (guideY > 0) guideY else existing.guideY
            ).also { current[existingIndex] = it }
        } else {
            TapPreset(
                id = cleanId ?: "preset-${System.currentTimeMillis()}",
                name = name.trim().ifEmpty { "新規プリセット" },
                targetHour = hour.coerceIn(0, 23),
                targetMinute = minute.coerceIn(0, 59),
                targetSecond = second.coerceIn(0, 59),
                targetMillisecond = millisecond.coerceIn(0, 999),
                targetX = if (targetX > 0) targetX else (lastCoords?.target1X ?: 540),
                targetY = if (targetY > 0) targetY else (lastCoords?.target1Y ?: 700),
                guideX = if (guideX > 0) guideX else (lastCoords?.guideX ?: 540),
                guideY = if (guideY > 0) guideY else (lastCoords?.guideY ?: 1150)
            ).also { current.add(it) }
        }

        saveAll(current)
        setLastSelectedPresetId(preset.id)
        saveLastCoordinates(preset.targetX, preset.targetY, preset.guideX, preset.guideY)
        return preset
    }

    fun deletePreset(id: String): Boolean {
        val current = getAllPresets().filter { it.id != id }
        if (current.isEmpty()) {
            saveAll(defaultPresets())
        } else {
            saveAll(current)
        }
        return true
    }

    fun defaultPresets(): List<TapPreset> {
        return listOf(
            TapPreset(
                id = "preset-1",
                name = "月曜 ヨガ予約",
                targetHour = 21,
                targetMinute = 0,
                targetSecond = 59,
                targetMillisecond = 500,
                targetX = 540,
                targetY = 700,
                guideX = 540,
                guideY = 1150
            ),
            TapPreset(
                id = "preset-2",
                name = "水曜 ピラティス",
                targetHour = 12,
                targetMinute = 0,
                targetSecond = 59,
                targetMillisecond = 500,
                targetX = 540,
                targetY = 750,
                guideX = 540,
                guideY = 1200
            ),
            TapPreset(
                id = "preset-3",
                name = "金曜 ダンス",
                targetHour = 19,
                targetMinute = 30,
                targetSecond = 59,
                targetMillisecond = 500,
                targetX = 540,
                targetY = 800,
                guideX = 540,
                guideY = 1250
            ),
            TapPreset(
                id = "preset-4",
                name = "iTipness 朝07:00予約",
                targetHour = 6,
                targetMinute = 59,
                targetSecond = 59,
                targetMillisecond = 950,
                targetX = 540,
                targetY = 650,
                guideX = 540,
                guideY = 1100
            )
        )
    }
}
