# Timer Auto Clicker Pro (Android専用ネイティブアプリ)

「Timer Auto Clicker」の不満点をすべて解消した、完全無料・高精度NTP同期・位置＆時刻保存対応のオートクリッカーです。

## 主な特徴
1. **完全無料・サブスクなし・広告なし**: 全機能を無制限で使用可能。
2. **位置(X, Y)と指定時刻のプリセット保存**: 「iTipness 07:00 検索ボタン」など、名前を付けて無制限に保存・ワンタップで瞬時に呼び出し可能。
3. **NICT / Cloudflare NTP ミリ秒同期**: スマホ内蔵時計のズレを解消し、日本標準時ミリ秒ジャストに発火。
4. **最前面フローティングオーバーレイ**: 他のどのアプリ（Chrome、予約アプリ等）の上にも紫色の丸ターゲットとミニ操作パネルが浮き続けます。
5. **0ms OSハードウェアタッチエミュレーション**: Android `AccessibilityService` の `dispatchGesture` により、遅延なく瞬時にタップ信号を発行。

## APKの作成方法（2つの簡単な手順）

### 方法A: GitHub Actions を使う方法（PC不要・スマホだけで完結・無料）
1. GitHub (github.com) で無料のアカウントを作成し、新しいリポジトリを作成します。
2. このZIPを展開した中身をGitHubリポジトリにアップロードします。
3. リポジトリの「Actions」タブを開くと、自動でAPKビルドが開始されます（約2分）。
4. ビルド完了後、「TimerAutoClickerPro-Debug-APK」から `app-debug.apk` をスマホにダウンロードしてインストールします。

### 方法B: Android Studio を使う方法（PCをお持ちの場合）
1. 無料の [Android Studio](https://developer.android.com/studio) をPCにインストールします。
2. 「Open」からこの `android` フォルダを選択して開きます。
3. メニューバーの「Build」>「Build Bundle(s) / APK(s)」>「Build APK(s)」をクリックします。
4. 数分で `app/build/outputs/apk/debug/app-debug.apk` が生成されます。
5. スマホに転送（GoogleドライブやUSB経由）してインストールします。
